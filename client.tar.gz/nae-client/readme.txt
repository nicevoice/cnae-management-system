*****************
安装nae客户端
****************
	>wget http://cnodejs.net/download/install.sh
	>chmod +x ./install.sh
	>sudo ./install.sh

	安装之后
	>nae 
	将打印出版本信息,说明安装成功

	
****************
使用nae客户端
****************

	在开始之前，请仔细阅读这段说明。
	=============
	nae client在开始使用时需要先身份认证，身份认证需要使用auth命令获取身份认证
		>nae auth 
	份认证成功之后，会在~/.nae_auth文件中保存认证的token信息。所以当切换用户时，需要重新认证。
	
	nae client执行download动作时，是将服务器端的代码同步到本地。
	同步的过程中，“会删除本地有而服务器端没有的文件！！！”
	所以在使用download之前，请先commit本地代码，以防代码丢失。
	
	nae client执行upload的时候，同样，“会将本地没有而服务器端有的文件删除！！！”
	所以在upload之前，如有必要，请先备份服务器端代码。
	=============
	身份认证
	>nae auth

	查看app状态
	>nae status appname

	启动app
	>nae start appname

	关闭app
	>nae stop appname

	重启app
	>nae restart appname

	调试app,捕获服务器端app的输出信息，
	>nae debug appname

	上传app, 上传的时候，有需要排除的文件
	比如.project .setting等文件，可以创建一个.naeignore文件，每行一个正则表达，匹配则忽略文件和目录
	>nae upload appname

	下载app，下载之后，目录中会有一个索引文件，.naeindex ,这是一个diff文件，不要删除它，client需要这个文件
	>nae download appname
	
	帮助信息
	>nae help
	
	更新客户端
	>sudo nae update
	==============
	当cd到app目录中时，nae命令可以省略appname，比如:
		nae start
		nae restart
	
	
	