#!/bin/sh

nae=nae.tar.gz
install_path=/usr/local/lib/nae
count=0

if [ ! -d $install_path ] ;then
		
fi

# make dir for lib
mkdir -p install_path

cd 
# download package
wget http://cnodejs.net/c

# extract file
tar xfz /usr/local/lib/nae/nae.tar.gz