var http = require('http'),
    emitter = require('event').EventEmitte,
    db = require('config').db,
    welcomeEmitter = new emitter();
http.createServer(function(req, res){
      welcomeEmitter.once('mongoDB', function(mongoMsg){
         res.writeHead(200, {"content-type":"text/html;charset=utf8"});
         res.data(mongoMsg);
         res.end("hello,cnode app engine!");
      })
      }).listen(80);
console.log("server started at port 80");

//mongoDB测试示例函数。如果已经开启mongoDB，请先去config.js修改填入DB用户名和密码。
function testMongo(){
    var testMongo = db.collection("testMongo");
    testMongo.save({title:"welcome",words:"欢迎来到node的世界。这条欢迎语通过mongoDB发出。"}, function(err){
      if(err){
          console.log("mongoDB没有启用。");
          welcomeEmitter.emit('mongoDB', 'mongoDB没有启用。');
      }else{
          testMongo.findOne({title:"welcome"}).toArray(err, data){
              if(err){
                  console.log("mongoDB没有启用。");
                  welcomeEmitter.emit('mongoDB', 'mongoDB没有启用。');
              }else{  
                  console.log(data.words);
                  testMongo.remove({title:"welcome"},function(){});        
                  welcomeEmitter.emit('mongoDB', data.words);                 
              }
          }
      }
   })
}
