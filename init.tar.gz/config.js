var mongo = require("mongoskin");

//change the url to "user:password@127.0.0.1:20088";
var db_url = exports.db_url = "user:password@127.0.0.1:20088";

exports.db = mongo.db(db_url);
