var vm = require('vm'),
	fs = require('fs'),
	Children = require('../lib/children');

var conf = {
	base : __dirname + '/apps/',
	data : __dirname + '/' + 'apps/apps_info.json'
};

function cleanData() {
	try{
		fs.unlinkSync(conf.data);
	} catch (e) {
		if (e.message.indexOf('No such file or directory') < 0) {
			throw e;
		}
		return;
	}
}

cleanData();
var c = Children.create(conf);
c.run('net_demo');