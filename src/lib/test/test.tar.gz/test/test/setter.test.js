

function Foo() {
    this.name = 'foo';
    var ondata = null;
    this.__defineGetter__('ondata', function() {
        return ondata;
    });
    this.__defineSetter__('ondata', function(fn) {
        console.log('setter')
        console.log(this);
        ondata = fn;
    });
};

var foo = new Foo();

foo.ondata = function() {
    console.log('ondata call.')
};
console.log(foo.ondata)
foo.ondata();

