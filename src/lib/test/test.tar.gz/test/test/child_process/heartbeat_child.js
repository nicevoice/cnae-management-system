var hb = require('../../lib/heartbeat.js').create({timeout:1000, app:'test1'});
hb.start();
process.on('message', function(msg){
	if (msg == 'stop') {
		hb.stop();
		process.exit();
	}
})