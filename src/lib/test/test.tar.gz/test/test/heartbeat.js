var cp = require('child_process');
exports.heartbeat = function(t) {
	var c = cp.fork(__dirname + '/child_process/heartbeat_child');
	var flag = false;
	c.on('message', function(m){
		if (flag) {
			t.ok(m.uptime >= 1, 'run two times');
			c.send('stop');
		} else {
			t.equal(0, m.uptime, 'run one time');
		}
		t.ok(m.rss > 0);
		t.ok(m.vsize > 0);
		t.ok(m.heapTotal > 0);
		t.ok(m.heapUsed > 0);
		t.equal('test1', m.app);
		t.equal('heartbeat', m.cmd);
		t.equal(c.pid, m.pid);
		flag = true;
	});
	c.on('exit', function() {
		t.done();
	})
}