var b = {
	v : 'b',
	a : require('./exports_a')
}
module.exports = b;