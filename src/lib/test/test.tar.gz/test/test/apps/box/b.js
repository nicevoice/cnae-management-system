exports.c = require('require_box_c');
exports.p = process;
exports.v = 2;
exports.fs = require('fs');
exports.allow = require('require_allow');
exports.gtest = Object.gtest;
