Object.gtest = function() {
	return 1;
}
var a = require('./a.js');
exports.p = process;
exports.v = 0;
exports.a = a;
exports.b = a.b;
exports.c = a.b.c;
exports.fs = require('fs');
exports.allow = require('require_allow');

//var http = require('http');

/*http.createServer(function(req, resp) {
	resp.writeHead({'Content-Type' : 'test/plain'});
	resp.write('box1: ' + process.setuid.toString() + "\r\n");
	resp.end('box2: ' + a.b.process.setuid.toString());
}).listen(8125);*/
