exports.a = require('./loop_a');
exports.v = 'b';