exports.b = require('./loop_b');
exports.v = 'a';
