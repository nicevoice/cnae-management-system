var b = require('./b.js');
exports.p = process;
exports.b = b;
exports.v = 1;
exports.fs = require('fs');
exports.allow = require('require_allow');
exports.gtest = Object.gtest;
