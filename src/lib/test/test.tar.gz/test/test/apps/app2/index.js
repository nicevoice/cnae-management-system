var http = require('http');
http.createServer(function(req, resp) {
	resp.end('app2: ' + req.url);
}).listen(8122);
