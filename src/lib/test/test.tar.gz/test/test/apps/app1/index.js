var http = require('http');

console.log(123);
console.warn(456);

http.createServer(function(req, resp) {
	resp.end('app1: ' + req.url);
}).listen(8123);