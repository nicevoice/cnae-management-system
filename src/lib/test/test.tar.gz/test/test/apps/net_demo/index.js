var http = require('http');

//var server = net.createServer(function (socket) {
//  socket.end("goodbye\n");
//});
//
//// grab a random port.
//server.listen(function() {
//  address = server.address();
//  console.log("opened server on %j", address);
//  console.log(server.fd);
//});
//
var server2 = http.createServer(function(req, res) {
	res.writeHead(200, {'Content-Type': 'text/plain'});
	res.end('okay ' + req.url);
});

server2.listen(8000, function() {
	address = server2.address();
	console.log("opened server on %j", address);
	console.log(server2.fd);
});

//var server3 = net.createServer(function (socket) {
//	socket.end("goodbye\n");
//});
//
//server3.listen(1024, function() {
//	address = server3.address();
//	console.log("opened server on %j", address);
//});
