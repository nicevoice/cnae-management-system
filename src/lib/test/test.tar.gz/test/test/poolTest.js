/* vim: set expandtab tabstop=4 shiftwidth=4 foldmethod=marker: */
/**
 * 连接池测试
 */

var cases	= require('nodeunit').testCase;
var mpool	= require('../lib/pool.js');
var Net     = require('net');
var File    = require('fs');

module.exports	= cases({
    setUp	: function(callback) {
        callback();
    },

    tearDown : function(callback){
        callback();
    },

    /* {{{ test_should_unix_socket_connect_pool_works_fine() */
    test_should_unix_socket_connect_pool_works_fine : function(test) {
        var master  = Net.createServer(function(socket) {
            socket.on('data', function(data) {
                socket.write('hello' + data);
            });
            socket.on('error', function(e) {
                if ('EPIPE' != e.code) {
                    throw e;
                }
            });
        });
        master.listen('./pool_test.sock');

        var pool= mpool.create(2, './pool_test.sock');
        pool.get(function(socket, idx) {
            //console.log(pool);
            //test.equal([0,1], pool.stack);
            socket.on('data', function(data) {
                pool.release(idx);
                test.equal('hello123456', data.toString());
                pool.close(function() {
                    master.close();
                    File.unlink('./pool_test.sock', function(e){
                    });
                    test.done();
                });
            });
            socket.write('123');
            socket.write('456');
            socket.end();
        });
    },
    /* }}} */

});

