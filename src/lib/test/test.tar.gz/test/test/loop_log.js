var log = require('../lib/loop_log');

exports.test_simple_log = function(t){
	var l = log.create();
	l.add(new Buffer('abc\n'));
	l.add(new Buffer('def\n'));
	l.add(new Buffer('higk\n'));
	t.equal('higk\ndef\nabc\n', l.get().toString(), 'get all log');
	t.equal('higk\ndef\n', l.get(2).toString(), 'get last 2 log');
	l.close();
	t.done();
}

exports.test_multi_line_log = function(t){
	var l = log.create();
	l.add(new Buffer('abc\ndef\n'));
	l.add(new Buffer('higk\n'));
	t.equal('higk\ndef\nabc\n', l.get().toString(), 'get all log');
	t.equal('higk\ndef\n', l.get(2).toString(), 'get last 2 log');
	l.close();
	t.done();
}

exports.test_oversize_log = function(t){
	var l = log.create({
		lineSize : 6,
	});
	l.add(new Buffer('123456'));
	l.add(new Buffer('1234567'));
	l.add(new Buffer('12345678'));
	t.equal('123456123456123456', l.get().toString());
	l.close();
	t.done();
}
exports.test_loop_log = function(t){
	var l = log.create({
		bufferSize : 16,
		lineSize : 8
	});
	l.add(new Buffer('aaaaaaa'));
	l.add(new Buffer('bbbbbbb'));
	t.equal('bbbbbbbaaaaaaa', l.get().toString(), 'buffer full');
	l.clear();
	l.add(new Buffer('aaaaaaa'));
	l.add(new Buffer('b'));
	l.add(new Buffer('cccccc'));
	t.equal('ccccccb', l.get().toString(), 'just over buffer');
	l.add(new Buffer('aaaaaaa'));
	l.add(new Buffer('b'));
	l.add(new Buffer('ccccccc'));
	t.equal('cccccccb', l.get().toString(), 'over 2 bytes');

	l.add(new Buffer('aaaaaaa'));
	l.add(new Buffer('b'));
	l.add(new Buffer('ccccccc'));
	l.add(new Buffer('dddddddd'));
	t.equal('dddddddd', l.get().toString(), 'over again');
	l.close();
	t.done();
}
