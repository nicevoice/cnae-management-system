var util = require("util");
var events = require("events");
var net = require('net');
var cli = require('../lib/command_line');
var testCase	= require('nodeunit').testCase;
var options = {
	log_level : 'INFO',
	log_options : {},
	max_size : 1048576,
	max_head : 1024,
	listen : 1235,
	client_timeout : 10000,
}


var MockClient = function(writeCallback, endCallback){
	this.writeCallback = writeCallback;
	this.endCallback = endCallback;
	this.timeout = null;
	//this.e = new events.EventEmitter();
	events.EventEmitter.call(this);
	//.call(this);
}
util.inherits(MockClient, events.EventEmitter);

MockClient.prototype.write = function (data){
	if (this.writeCallback) {
		this.writeCallback(data);
	}
}
MockClient.prototype.end = function (data){
	if (this.endCallback) {
		this.endCallback(data);
	}
}
/*MockClient.prototype.on = function(evt, cb) {
	this.e.on(evt, cb);
}*/
MockClient.prototype.send = function(data){
	//this.e.emit("data", data);
	this.emit("data", data);
}
MockClient.prototype.setTimeout = function(time, cb) {
	if (this.timeout) {
		clearTimeout(this.timeout);
	}
	var self = this;
	this.timeout = setTimeout(function(){
		cb.apply(this);
	});
}


var TestClient = function(done){
	var self = this;
	this.cli = net.createConnection(options.listen, 'localhost', function(){
		if (done){
			done();
		}
	});

}
TestClient.prototype.start = function(res){

	this.cli.on('data', function(data){
		res(data);
	});
}
TestClient.prototype.stop = function() {
	this.cli.end();
}

TestClient.prototype.cmd = function(){
	var head = '', body;
	for (k in arguments) {
		head += arguments[k] + ' ';
		if (k == 4) {
			body = arguments[4];
		}
	}
	head = head.trim();
	this.cli.write(head + "\n");
}


var MockChildren = function(){
}

MockChildren.prototype.getStatus = function(){
	return {
		rss : 1,
		heap : 2,
		uptime : 3,
		pid : 4,
	}
}
MockChildren.prototype.getList = function(){
	return ['a1', 'a2'];
}
MockChildren.prototype.getAppStatus = function(app){
	if (app == 'a1') {
		return {
			rss : 201,
			heap : 202,
			uptime : 203,
			last : 204,
			pid : 205,
			autorun : false,
			running : false,
			ports : [206, 207]
		}
	} else {
		return {
			rss : 101,
			heap : 102,
			uptime : 103,
			last : 104,
			pid : 105,
			autorun : true,
			running : true,
			ports : [106, 107]
		}
	}
}
MockChildren.prototype.getAppLog = function(app, lineNum, errLog) {
	return new Buffer(app + ' ' + lineNum + ' ' + (errLog ? 'true' : 'false'));
}
MockChildren.prototype.run = function(app, cb) {
	var self = this;
	process.nextTick(function(){
		if (app == 'a3') {
			cb(new Error('a3 start error'), app);
		} else {
			cb(null, app);
		}

		//self.cb('run', app);
	})
}

MockChildren.prototype.stop = function(app, auto, cb) {
	var self = this;
	process.nextTick(function(){
		cb(null, app);
		//self.cb.apply(self, 'stop', app);
	})
}
MockChildren.prototype.stopDebug = function(app) {
}
MockChildren.prototype.startDebug = function(app) {
}

module.exports = testCase({


	setUp	: function(callback) {
		// box.children = new MockChildren();
		// box.server = new cli.Server(options, box.children, function(){
		// 	box.client = new TestClient(function(){
		// 		callback();
		// 	})
		// })
		callback();
	},

	tearDown : function(callback){
		// box.client.stop();
		// box.server.stop();
		callback();
	},

	should_client_parse_one_command_without_body_works_fine : function(t) {
		var c ;
		c = new cli.Command(options, function(head){
			t.deepEqual({cmd : 'start', app : 'app1', key : null, size : 0}, head, 'start ok');
		});
		c.onData(new Buffer("start app1\n"));
		c = new cli.Command(options, function(head){
			t.deepEqual({cmd : 'stop', app : 'app1', key : null, size : 0}, head, 'stop ok');
		});
		c.onData(new Buffer("stop app1\n"));
		c = new cli.Command(options, function(head){
			t.deepEqual({cmd : 'debug_start', app : 'app1', key : null, size : 0}, head, 'debug_start ok');
		});
		c.onData(new Buffer("debug_start app1\n"));
				c = new cli.Command(options, function(head){
			t.deepEqual({cmd : 'debug_stop', app : 'app1', key : null, size : 0}, head, 'debug_stop ok');
		});
		c.onData(new Buffer("debug_stop app1\n"));
		c = new cli.Command(options, function(head){
			t.deepEqual({cmd : 'stdout', app : 'app1', key : null, size : 100}, head, 'stdout ok');
		});
		c.onData(new Buffer("stdout app1 100\n"));
		c = new cli.Command(options, function(head){
			t.deepEqual({cmd : 'stderr', app : 'app1', key : null, size : 100}, head, 'stderr ok');
		});
		c.onData(new Buffer("stderr app1 100\n"));
		c = new cli.Command(options, function(head){
			t.deepEqual({cmd : 'stdout_start', app : 'app1', key : null, size : 0}, head, 'stdout_start ok');
		});
		c.onData(new Buffer("stdout_start app1\n"));
		c = new cli.Command(options, function(head){
			t.deepEqual({cmd : 'stderr_start', app : 'app1', key : null, size : 0}, head, 'stderr_start ok');
		});
		c.onData(new Buffer("stderr_start app1\n"));
		c = new cli.Command(options, function(head){
			t.deepEqual({cmd : 'stdout_stop', app : 'app1', key : null, size : 0}, head, 'stdout_stop ok');
		});
		c.onData(new Buffer("stdout_stop app1\n"));
		c = new cli.Command(options, function(head){
			t.deepEqual({cmd : 'stderr_stop', app : 'app1', key : null, size : 0}, head, 'stderr_stop ok');
		});
		c.onData(new Buffer("stderr_stop app1\n"));
		c = new cli.Command(options, function(head){
			t.deepEqual({cmd : 'status', app : 'app1', key : null, size : 0}, head, 'status ok');
		});
		c.onData(new Buffer("status app1\n"));
		c = new cli.Command(options, function(head){
			t.deepEqual({cmd : 'index', app : 'app1', key : null, size : 0}, head, 'index ok');
		});
		c.onData(new Buffer("index app1\n"));
		c = new cli.Command(options, function(head){
			t.deepEqual({cmd : 'filedel', app : 'app1', key : 'dir/file.js', size : 0}, head, 'filedel ok');
		});
		c.onData(new Buffer("filedel app1 dir/file.js\n"));
		t.done();
	},
	should_client_parse_one_command_with_body_works_fine : function(t){
		var c ;
		c = new cli.Command(options, function(head){
			t.deepEqual({cmd : 'fileadd', app : 'app1', key : 'dir/file.js', size : 13}, head, 'fileadd single chunk head ok');
		}, function(data, info){
			t.equal('file_contents', data.toString());
			t.deepEqual({
				cmd : 'fileadd',
				app : 'app1',
				key : 'dir/file.js',
				size : 13,
				left : 0
			}, info, 'fileadd single chunk body ok');
		});
		c.onData(new Buffer("fileadd app1 13 dir/file.js\nfile_contents"));

		var flag = false;
		c = new cli.Command(options, function(head){
			t.deepEqual({cmd : 'fileedit', app : 'app1', key : 'dir/file.js', size : 21}, head, 'fileedit multi chunkes head ok');
		}, function(data, info){
			//console.log(data.len);
			if (flag) {
				t.equal('content2', data.toString());
				t.deepEqual({
					cmd : 'fileedit',
					app : 'app1',
					key : 'dir/file.js',
					size : 21,
					left : 0
				}, info, 'fileedit multi chunkes body2 ok');
			} else {
				t.equal('file_contents', data.toString());
				t.deepEqual({
					cmd : 'fileedit',
					app : 'app1',
					key : 'dir/file.js',
					size : 21,
					left : 8
				}, info, 'fileedit multi chunkes body1 ok');
				flag = true;
			}
		});
		c.onData(new Buffer("fileedit app1 21 dir/file.js\nfile_contents"));
		c.onData(new Buffer("content2"));
		t.expect(8);
		t.done();
	},
	should_client_parse_chunked_commands_works_fine : function(t) {
		var flag = 0;
		var c = new cli.Command(options, function(head){
			switch(flag++) {
				case 0:
					t.deepEqual({cmd : 'start', app : 'app1', key : null, size : 0}, head, 'command 1 ok');
					break;
				case 1:
					t.deepEqual({cmd : 'stop', app : 'app2', key : null, size : 0}, head, 'command 2ok');
					break;
				case 2:
					t.deepEqual({cmd : 'status', app : 'app3', key : null, size : 0}, head, 'command 3 ok');
					break;
				default:
					t.equal(false, 'no more data send');
			}
		});
		c.onData(new Buffer("star"));
		c.onData(new Buffer("t app1"));
		c.onData(new Buffer("\n"));
		c.onData(new Buffer("stop"));
		c.onData(new Buffer(" app2\nstatus"));
		c.onData(new Buffer(" app3\n"));
		t.expect(3);
		t.done();
	},
	should_client_parse_mixed_commandes_works_fine : function(t) {
		var flag1 = flag2 = 0;
		var c = new cli.Command(options, function(head){
			switch(flag1++) {
				case 0:
					t.deepEqual({cmd : 'start', app : 'app1', key : null, size : 0}, head, 'command 1 head ok');
					break;
				case 1:
					t.deepEqual({cmd : 'fileadd', app : 'app2', key : 'dir/file', size : 10}, head, 'command 2 head ok');
					break;
				case 2:
					t.deepEqual({cmd : 'stop', app : 'app3', key : null, size : 0}, head, 'command 3 head ok');
					break;
				case 3:
					t.deepEqual({cmd : 'fileedit', app : 'app4', key : 'dir/file2', size : 20}, head, 'command 4 head ok');
					break;
				default:
					t.equal(false, 'no more data send');
			}
		}, function(body, info) {
			switch(flag2++) {
				case 0:
					t.equal('1234567890', body.toString(), 'command 2 body ok');
					t.deepEqual({
						cmd:'fileadd', app:'app2', key : 'dir/file', size:10, left:0
					}, info, 'command 2 body info ok');
					break;
				case 1 :
					t.equal('1234567890', body.toString(), 'command 2 body1 ok');
					t.deepEqual({
						cmd:'fileedit', app:'app4', key : 'dir/file2', size:20, left:10
					}, info, 'command 4 body1 info ok');
					break;
				case 2 :
					t.equal('0987654321', body.toString(), 'command 2 body2 ok');
					t.deepEqual({
						cmd:'fileedit', app:'app4', key : 'dir/file2', size:20, left:0
					}, info, 'command 4 body2 info ok');
					break;
				default:
					t.equal(false, 'no more data send');
				}
		});
		c.onData(new Buffer("start app1\n"));
		c.onData(new Buffer("fileadd app2 10 dir/file\n1234567890stop app3\nfileedit app4 20 dir/file2\n1234567890"));
		c.onData(new Buffer("0987654321"));
		t.done();
	},
	should_client_run_command_start_stop_and_restart_works_fine : function(t){
		var chd = new MockChildren()
		var flag = 0;
		var mockc = new MockClient(function(data){
			switch (flag++) {
				case 0:
					t.equal('{"status":"ok","msg":"App \\"a1\\" start ok."}\r\n', data.toString(), 'start ok');
					mockc.send(new Buffer('stop a2\n'));
					break;
				case 1:
					t.equal('{"status":"ok","msg":"App \\"a2\\" stop ok."}\r\n', data.toString(), 'stop ok');
					mockc.send(new Buffer('start a3\n'));
					break;
				case 2 :
					t.equal('{"status":"error","code":101,"msg":"a3 start error"}\r\n', data.toString(),'start error app')
					mockc.send(new Buffer('restart a1\n'));
					break;
				case 3 :
					t.equal('{"status":"ok","msg":"App \\"a1\\" start ok."}\r\n', data.toString(),'restart app a1')
					mockc.send(new Buffer('restart a2\n'));
					break;
				case 4 :
					t.equal('{"status":"ok","msg":"App \\"a2\\" restart ok."}\r\n', data.toString(),'restart app a2')
					t.done();
			}
		}, function(data){
			//console.log('end', data);
		});
		var c = new cli.Client(mockc, chd, options);
		mockc.send(new Buffer('start a1\n'));
	},

	should_client_run_command_status_and_std_works_fine : function(t){
		var chd = new MockChildren()
		var flag = 0;
		var mockc = new MockClient(function(data){
			switch (flag++) {
				case 0:
					t.equal('{"rss":201,"heap":202,"uptime":203,"last":204,"pid":205,"autorun":false,"running":false,"ports":[206,207]}\r\n', data.toString(), 'status ok');
					mockc.send(new Buffer('stdout a1 100\n'));
					break;
				case 1:
					t.equal('a1 100 false', data.slice(10).toString(), 'stdout ok');
					t.equal(data.length-10, data.slice(0, 10).readInt32BE(0), 'stdout length ok');
					mockc.send(new Buffer('stderr a2 200\n'));
					break;
				case 2:
					t.equal('a2 200 true', data.slice(10).toString(), 'stderr ok');
					t.equal(data.length-10, data.slice(0, 10).readInt32BE(0), 'stderr length ok');
					t.done();
			}
		}, function(data){
			//console.log('end', data);
		});
		var c = new cli.Client(mockc, chd, options);
		mockc.send(new Buffer('status a1\n'));
	}
});


