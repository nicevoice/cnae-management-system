//console.log(exports);
exports.index1 = 1;
exports.index2 = 1;
exports.fun = function(){
	console.log(231231);
}
exports.o = {a:1,b:2}
