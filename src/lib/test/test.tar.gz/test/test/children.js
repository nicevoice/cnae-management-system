var vm = require('vm'),
	fs = require('fs'),
	Children = require('../lib/children'),
	httpTest = require('./lib/http_test'),
	config = require('../lib/config'),
	testCase = require('nodeunit').testCase;
;

config.loadFromFile(__dirname + '/config.json');
var conf = config.getChildrenConfig();
conf.data = __dirname + '/' + 'apps/apps_info.json',
conf.debug = false;
conf.log_level = 'ERROR';

module.exports = testCase({
	setUp : function(callback) {
		try{
			fs.unlinkSync(conf.data);
		} catch (e) {
			if (e.message.indexOf('No such file or directory') < 0) {
				throw e;
			}
		}
		callback();
	},
		tearDown : function(callback) {
		try{
			fs.unlinkSync(conf.data);
		} catch (e) {
			if (e.message.indexOf('No such file or directory') < 0) {
				throw e;
			}
		}
		callback();
	},
	should_app_start_and_run_ok : function(t) {
		var c = Children.create(conf);
		c.run('app1', function(){
			setTimeout(function(){
				t.equal('123\n', c.getAppLog('app1', 1).toString(), 'stdout ok');
				t.equal('456\n', c.getAppLog('app1', 1, true).toString(), 'stderr ok');
				t.equal(c.proc.app1.process.pid, c.getAppStatus('app1').pid, 'pid not matched');
				t.ok(c.getAppStatus('app1').pid > 0, 'app1 prrocess not running');
				httpTest.run(t, 'http://localhost:8123/abc', 'app1: /abc', 'server 1 not start');
			}, 100);
		});
		c.run('app2', function(){
			setTimeout(function () {
				t.equal(['app1', 'app2'].toString(), c.getList().toString(), 'can get applist');
				t.equal(c.proc.app2.process.pid, c.getAppStatus('app2').pid, 'pid not matched');
				t.ok(c.getAppStatus('app1').running, 'app2 prrocess not running');
				httpTest.run(t, 'http://localhost:8122/123', 'app2: /123', 'server 2 not start');
			}, 100)
		});
		setTimeout(function(){
			c.quit(function(){
				t.expect(9);
				t.done();
			});
		}, 300);
	},
	should_stop_app_and_app_info_data_save_works_fine : function(t){
		var c= Children.create(conf);
		c.run('app1');
		setTimeout(function(){
			c.quit(function(){
				t.equal('{"app1":{"autorun":true}}', fs.readFileSync(conf.data).toString(), 'save auto run ok');
			});
		}, 100);
		setTimeout(function(){
			c = Children.create(conf);
		}, 300);
		setTimeout(function(){
			t.ok(c.getAppStatus('app1').running, 'app1 prrocess running');
			c.stop('app1', true, function(){
				t.ifError(c.getAppStatus('app1').running, 'app1 stop');
				c.quit(function(){
					setTimeout(function(){
						t.equal('{"app1":{"autorun":false}}', fs.readFileSync(conf.data).toString(), 'save auto run ok');
					}, 100);
				});
			});
		}, 400);
		setTimeout(function(){
			c = Children.create(conf);
		}, 700);
		setTimeout(function(){
			t.ifError(c.getAppStatus('app1').running, 'app1 prrocess running');
			c.quit();
		}, 800);
		setTimeout(function(){
			t.expect(5);
			t.done();
		}, 1000);
	}
});
