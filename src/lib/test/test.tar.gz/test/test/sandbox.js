var vm = require('vm'),
	fs = require('fs'),
	path = require('path'),
	sb = require('../lib/sandbox'),
	SandBox = sb.SandBox;

require('../lib/config').loadFromFile(__dirname + '/config.json');
var sb_file = path.normalize(__dirname + '/../lib/sandbox.js');


exports.should_get_paths_use_in_app_file_works_fine = function(t) {
	eval(fs.readFileSync(sb_file, 'utf-8'));
	t.deepEqual([
		 '/home/app/aa/bb/cc/node_modules'
		,'/home/app/aa/bb/node_modules'
		,'/home/app/aa/node_modules'
		,'/home/app/node_modules'
	], getPaths('/home/app/aa/bb/cc', '/home/app', '/home/nodepath1:/home/nodepath2'));
	t.done();
}



exports.should_get_paths_use_in_node_modules_file_works_fine = function(t) {
	eval(fs.readFileSync(sb_file, 'utf-8'));
	t.deepEqual([
		 '/home/nodepath1/aa/bb/cc/node_modules'
		,'/home/nodepath1/aa/bb/node_modules'
		,'/home/nodepath1/aa/node_modules'
		,'/home/nodepath1/node_modules'
	], getPaths('/home/nodepath1/aa/bb/cc', '/home/app', '/home/nodepath1:/home/nodepath2'));
	t.done();
}


exports.should_get_real_full_path_works_fine = function(t) {
	eval(fs.readFileSync(sb_file, 'utf-8'));
	t.equal(process.cwd() + '/dir/file', fullPath('./file', 'dir'), 'append subDir');
	t.equal(process.cwd() + '/file', fullPath('../file', 'dir'), 'append parentDir');
	t.equal('/abs/file', fullPath('/abs/file', 'dir'), 'absolute path');
	t.equal('native', fullPath('native', 'dir'), 'native module');
	t.throws(function(){
		fullPath('', 'dir')
	}, 'name blank');
	t.done();
}

exports.should_check_file_in_safty_path_works_fine = function(t) {
	eval(fs.readFileSync(sb_file, 'utf-8'));
	t.equal(__filename, checkSafety(__dirname + '/sandbox.js', __dirname), 'check with string');
	t.equal(__filename, checkSafety(__dirname + '/sandbox.js', ['/a/b/c/d', __dirname]), 'check with array');
	t.equal(__filename, checkSafety(__filename, __dirname), 'check with absolute path');
	t.equal('buffer', checkSafety('buffer', __dirname), 'native module');
	t.equal(false, checkSafety('aaa', __dirname), 'native module not exists');
	t.equal(false, checkSafety('./aaa.js', __dirname), 'module not exists');
	t.equal(false, checkSafety(__dirname + '/sandbox.js', '/a/b/c/'), 'access deny');
	t.done();
}

exports.should_init_safe_paths_works_fine = function(t) {
	var options = {
		filename : path.normalize(__dirname + '/apps/app1/lib/my.js'),
		dirname : path.normalize(__dirname + '/apps/app1'),
		nodePaths: __dirname + '/node_modules:'+__dirname + '/not_exists'
	}
	SandBox.setOptions(options);
	var s = new SandBox();
	t.deepEqual([
		__dirname + '/apps/app1',
	  __dirname + '/node_modules'
	], SandBox.safePaths, 'use absolute dir & skip wrong dir');

	var options = {
		filename : path.normalize(__dirname + '/apps/app1/lib/my.js'),
		dirname : path.normalize(__dirname + '/apps/app1'),
		nodePaths: '../../node_modules:../../not_exists'
	}
	SandBox.setOptions(options);
	var s = new sb.SandBox();
	t.deepEqual([
		__dirname + '/apps/app1',
	  __dirname + '/node_modules'
	], SandBox.safePaths, 'use relate dir');
	t.done();
}


exports.should_require_resolve_module_main_file_works_fine = function(t) {
	var options = {
		filename : path.normalize(__dirname + '/my.js'),
		dirname : path.normalize(__dirname),
		nodePaths: __dirname + '/node_modules:'+__dirname + '/not_exists',
		deny : {'vm' : true},
	}
	SandBox.setOptions(options);
	//var s = new SandBox();
	var parent = new SandBox(__filename);
	var parent = new SandBox('.');
	parent.filename = SandBox.homeDir + '/index.js';
	parent.setPaths();

	t.equal('buffer', SandBox._resolveFile('buffer', parent), 'native module');
	t.equal(__dirname + '/my/index.js', SandBox._resolveFile('./my', parent), 'default with index.js');
	t.equal(__dirname + '/my1/my.js', SandBox._resolveFile('./my1', parent), 'default with package.json');
	t.equal(__dirname + '/my/my.js', SandBox._resolveFile(__dirname + '/my/my.js', parent), 'absolute path');
	t.throws(function(){SandBox._resolveFile('aaa', parent)}, 'module not exists');
	t.throws(function(){SandBox._resolveFile('../require.js', parent)}, 'dir safety');
	t.throws(function(){SandBox._resolveFile('vm', parent)}, 'module deny');
	t.done();
}


exports.should_require_simple_module_works_fine = function(t) {
	var options = {
		filename : path.normalize(__dirname + '/my'),
		dirname : path.normalize(__dirname),
		nodePaths: __dirname + '/node_modules:'+__dirname + '/not_exists',
	}
	SandBox.setOptions(options);
	SandBox.clearCache();
	var parent = new SandBox(__dirname + '/my/index.js', __dirname + '/my/index.js');
	parent.filename = __dirname + '/my/index.js';
	parent.setPaths();

	// var v = SandBox._loadFile('vm', parent);
	// t.equal(vm, v, 'load native module ok');
	var my = SandBox.run();
	t.equal(1, my.index1, 'load with index.js ok');

	options.filename = path.normalize(__dirname + '/my/my');
	SandBox.setOptions(options);
	SandBox.clearCache();
	var my1 = SandBox.run();
	t.equal(2, my1.my1, 'load with full path ok');

	options.filename = path.normalize(__dirname + '/my1');
	SandBox.setOptions(options);
	SandBox.clearCache();
	var my2 = SandBox.run();
	t.equal(3, my2.my1, 'load with package info path ok');
	t.done();
}

exports.should_require_with_sub_module_works_fine = function(t) {
	var options = {
		filename : path.normalize(__dirname + '/apps/box/'),
		dirname : path.normalize(__dirname),
		nodePaths: __dirname + '/node_modules',
		map : {'fs' : {a:1}},
		//allow : {'require_allow' : true}
	}
	SandBox.setOptions(options);
	var deep = SandBox.run();

/*
	t.ok(deep.allow.allow, 'a allow ok');
	t.ok(deep.a.allow.allow, 'a allow ok');
	t.ok(deep.b.allow.allow, 'b allow ok');
	t.ok(deep.c.allow.allow, 'c allow ok');
*/
	t.equal(1, Object.gtest(), 'global unvar in index ok');
	t.equal(1, deep.a.gtest(), 'global unvar in a ok');
	t.equal(1, deep.b.gtest(), 'global unvar in b ok');
	t.equal(1, deep.c.gtest(), 'global unvar in c ok');
	t.equal(0, deep.v, 'index ok');
	t.equal(1, deep.a.v, 'index require a ok');
	t.equal(2, deep.b.v, 'a require b ok');
	t.equal(3, deep.c.v, 'a require node_modules_c ok');
	t.equal(undefined, deep.p.env.PWD, 'process box index a ok');
	t.equal(undefined, deep.a.p.env.PWD, 'process box in a ok');
	t.equal(undefined, deep.b.p.env.PWD, 'process box in b ok');
	t.equal(undefined, deep.c.p.env.PWD, 'process box in node_modules_c ok');
	t.ok(1, deep.fs.a, 'fs mapped in index');
	t.ok(1, deep.a.fs.a, 'fs mapped in a');
	t.ok(1, deep.b.fs.a, 'fs mapped in b');
	t.ok(1, deep.c.fs.a, 'fs mapped in node_modules_c');
	t.done();
}

exports.should_circular_require_with_exports_works_fine = function(t) {
	var options = {
		filename : path.normalize(__dirname + '/apps/box/loop_a.js'),
		dirname : path.normalize(__dirname),
		nodePaths: __dirname + '/node_modules',
//		map : {'fs' : require('../lib/modules/fs')},
		//allow : {'require_allow' : true}
	}
	SandBox.setOptions(options);
	var loop = SandBox.run();
	t.equal('a', loop.v, 'require a ok');
	t.equal('b', loop.b.v, 'require b ok');
	t.equal('a', loop.b.a.v, 'require a in b ok');
	t.equal('b', loop.b.a.b.v, 'require a in b in a ok');
	t.done();
}

exports.should_circular_require_with_module_exports_works_fine = function(t) {
	var options = {
		filename : path.normalize(__dirname + '/apps/box/exports_a.js'),
		dirname : path.normalize(__dirname),
		nodePaths: __dirname + '/node_modules',
//		map : {'fs' : require('../lib/modules/fs')},
		//allow : {'require_allow' : true}
	}
	SandBox.setOptions(options);
	var loop = SandBox.run();
	//console.log(loop);
	t.equal('a', loop.v, 'require a ok');
	t.equal('b', loop.b.v, 'require b ok');
	t.equal('a', loop.b.a.v, 'require a in b ok');
	t.equal('b', loop.b.a.b.v, 'require a in b in a ok');
	t.done();
}


