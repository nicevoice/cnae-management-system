var httpConsole = require('../lib/http_console.js'),
	httpTest = require('./lib/http_test');
var success = {'status': 'success'},
	failure = {'status': 'failure'},
	failApp = 'failApp';
var children = {
	getStatus: function(){
		return {'status': 'ok'};
	},
	getList: function(){
		return ['app1', 'app2'];
	},
	getAppStatus: function(app){
		if(app == failApp){
			return null;
		}
		//return {'name': app};
		return {
			rss : 1,
			heap : 2,
			uptime : 3,
			last : 4,
			pid : 5,
			autorun : 0,
			running : false
		}
	},
	getAppLog: function(app, line, err){
		var log = err ? 'err\n' : 'out\n';
		for(var i = 0; i < line; i++){
			log += app + '\n';
		}
		return log;
	},
	run: function(app, cb){
		if(app == failApp){
			cb('err');	//fail
		}else{
			cb(null);	//success
		}
	},
	stop: function(app, flag, cb){
		if(app == failApp){
			cb('err');	//fail
		}else{
			cb(null);	//success
		}
	}
};
var conf = {
	listen: 7778,
	children: children
};
var url = 'http://localhost:' + conf.listen;
httpConsole.set(conf);
httpConsole.start();

module.exports = {
	getStatus: function(t){
		setTimeout(function(){
			httpTest.run(t,
				url + '/status',
				children.getStatus(),
				'get status fail',
				{done: done(t)}
			);
		}, 500);
	},
	getApps: function(t){
		httpTest.run(t,
			url + '/apps',
			children.getList(),
			'get apps fail',
			{done: done(t)}
		);
	},
	getAppInfoSuccess: function(t){
		var appname = 'myapp';
		httpTest.run(t,
			url + '/app/' + appname,
			children.getAppStatus(appname),
			'get app fail(' + appname + ')',
			{done: done(t)}
		);
	},
	getAppInfoFail: function(t){
		var appname = failApp;
		httpTest.run(t,
			url + '/app/' + appname,
			failure,
			'should fail(' + appname + ')',
			{done: done(t)}
		);
	},
	getAppErrLog: function(t){
		var appname = 'myapp';
		httpTest.run(t,
			url + '/app_log/err/' + appname + '/last/5',
			children.getAppLog(appname, 5, true),
			'get app stderr log fail(' + appname + ')',
			{done: done(t)}
		);
	},
	getAppOutLog: function(t){
		var appname = 'myapp';
		httpTest.run(t,
			url + '/app_log/out/' + appname + '/last/3',
			children.getAppLog(appname, 3, false),
			'get app stdout log fail(' + appname + ')',
			{done: done(t)}
		);
	},
	postAppRunSuccess: function(t){
		var appname = 'myapp';
		httpTest.run(t,
			url + '/app/' + appname + '/run',
			success,
			'run app fail(' + appname + ')',
			{method: 'POST', done: done(t)}
		);
	},
	postAppRunFail: function(t){
		var appname = failApp;
		httpTest.run(t,
			url + '/app/' + appname + '/run',
			failure,
			'should fail(' + appname + ')',
			{method: 'POST', done: done(t)}
		);
	},
	postAppStopSuccess: function(t){
		var appname = 'myapp';
		httpTest.run(t,
			url + '/app/' + appname + '/stop',
			success,
			'stop app fail(' + appname + ')',
			{method: 'POST', done: done(t)}
		);
	},
	postAppStopFail: function(t){
		var appname = failApp;
		httpTest.run(t,
			url + '/app/' + appname + '/stop',
			failure,
			'should fail(' + appname + ')',
			{method: 'POST', done: done(t)}
		);
	}
};
var caseNum = 0;
for(var c in module.exports){
	caseNum++;
}
function checkDone(num){
	if(num == caseNum){
		httpConsole.stop();
	}
}
var resNum = 0;
var done = function(t){
	return function(){
		checkDone(++resNum);
		t.done();
	}
};
process.on('uncaughtException', function(err){
	httpConsole.stop();
});
