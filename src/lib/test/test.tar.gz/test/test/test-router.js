var server = require('../lib/router.js').createServer(),
	httpTest = require('./lib/http_test');
var port = 7779;
var url = 'http://localhost:' + port;

var paths = [
	'/hi',
	'/hi/:name1',
	'/hi/:name1/world',
	'/hi/:name1/world/:name2/:name3',
	'/:name1/:name2'
];
var _404 = 'page not found\n';
var reqs = {
	'/hi': 					{
							 'rule': '/hi',
							 'params': {}
							},
	'/hi/': 				{
							 'rule': '/hi',
							 'params': {}
							},
	'/hi/aa': 				{
							 'rule': '/hi/:name1', 
							 'params': {'name1': 'aa'}
							},
	'/hi/aa/world': 		{
							 'rule': '/hi/:name1/world', 
							 'params': {'name1': 'aa'}
							},
	'/hi/aa/world/bb': 		_404,
	'/hi/aa/world/bb/cc':	{
							 'rule': '/hi/:name1/world/:name2/:name3', 
							 'params': {'name1': 'aa', 'name2': 'bb', 'name3': 'cc'}
							},
	'/aa/bb': 				{
							 'rule': '/:name1/:name2', 
							 'params': {'name1': 'aa', 'name2': 'bb'}
							},
	'/aa/bb/cc': 			_404
};
/*
var rules = {
	'GET /status': {cb: getStatus},
	'GET /apps': {cb: getList},
	'GET /app/:appname': {cb: getAppStatus, patt: new RegExp('GET /app/([^/]+)')},
	'POST /app/:appname/run': {cb: run, patt: /POST \/app\/([^\/]+)\/run/},
	'POST /app/:appname/stop': {cb: stop, patt: /POST \/app\/([^\/]+)\/stop/}
};
*/
server.listen(port);
for(var i = 0; i < paths.length; i++){
	server.get(paths[i], echo(paths[i]));
}
function echo(path){
	return function(req, res){
		var result = {
			method: req.method,
			rule: path
		};
		if(req.params){
			result.params = req.params;
		}
		res.end(JSON.stringify(result));
	}
}
module.exports = {
	testWriteRule: function(t){
		var path = '/hi/:name1';
		setTimeout(function(){
			server.get(path, echo(path));
			t.equal(server.rules['GET ' + path].patt.toString(), 
					'/GET \/hi\/([^\/]+)\/?$/', 
					'write rule fail ("GET ' + path + '")'
					);
			t.done();
		}, 500);
	},
	testRouter: function(t){
		caseNum = 0;
		for(var c in reqs){
			caseNum++;
		}
		var method = 'GET';
		for(var path in reqs){
			reqs[path].method = method;
			console.log(path);
			httpTest.run(t, 
				url + path, 
				reqs[path], 
				'router fail: ' + path, 
				{done: done(t), method: method}
			); 
		}
	}
}
var resNum = 0;
var done = function(t){
	return function(){
		checkDone(t, ++resNum);
	}
};
var caseNum = 0;
function checkDone(t, num){
	if(num == caseNum){
		server.close();
		t.done();
	}
}
