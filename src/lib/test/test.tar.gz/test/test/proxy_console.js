/* vim: set expandtab tabstop=4 shiftwidth=4 foldmethod=marker: */

var TestCase = require('nodeunit').testCase,
	Net = require('net'),
	File = require('fs'),
	Path = require('path'),
	ProxyConsole = require('../lib/proxy_console.js');

module.exports	= TestCase({
	setUp	: function(callback) {
		callback();
	},

	tearDown : function(callback){
		callback();
	},

	test_should_master_request_works_fine	: function(test) {
        var proxyConsole	= ProxyConsole.create(__dirname + '/config.json');
		setTimeout(function() {
            var client	= Net.createConnection(__dirname + '/run/proxy.sock');
			client.setNoDelay(true);
            client.on('error', function(e) {
                console.log(e);
			});

			var step	= 0;
            client.on('data', function(data) {
				switch (step) {
					case 0:
					test.equal('ERROR 41\r\nUsage: REGISTER [appname] [port] [socket]', data.toString().trim());
					client.write('aaa');
					break;

					case 1:
					test.equal('ERROR 25\r\nUndefined method as "AAA"', data.toString().trim());
					client.write('UNREGISTER app1');
					break;

					case 2:
					test.equal('ERROR 34\r\nUsage: UNREGISTER [appname] [port]', data.toString().trim());
					client.write('REGISTER app1 18081 /home/pengchun/a.sock');
					break;

					case 3:
					test.equal('OK 0', data.toString().trim());
					test.ok(undefined != proxyConsole.proxy['18081']);
					test.ok(Path.existsSync(__dirname + '/run/route/18081/app1'));
					test.equal('/home/pengchun/a.sock', File.readFileSync(
						__dirname + '/run/route/18081/app1'
					).toString().trim());
					client.write('UNREGISTER app1 18081');
					break;

					case 4:
					test.equal('OK 0', data.toString().trim());
					test.ok(undefined != proxyConsole.proxy['18081']);
					test.ok(!Path.existsSync(__dirname + '/run/route/18081/app1'));
					client.write('UNREGISTER i_am_not_exists 18081');
					break;

					case 5:
					test.equal('OK 0', data.toString().trim());
					client.write('STATUS');
					break;

					case 6:
					data	= data.toString().trim();
					test.equal(0, data.indexOf('OK '));
					test.ok(data.indexOf('uptime:') > 0);
					test.ok(data.indexOf('connections:') > 0);
					test.ok(data.indexOf('listening:') > 0);
					client.write('QUIT');
					break;

					default:
					test.equal('BYE', data.toString().trim());
					client.end();
					proxyConsole.shutdown();
					test.done();
					break;
				}
				step++;
			});
			client.write('REGISTER a');
		}, 200);
	},

});
