
var config = require('../../../lib/config');
config.loadFromFile(__dirname + '/../../config.json');

var testCase = require('nodeunit').testCase;
var oss = require('../../../lib/filesystem/oss');
var fs = require('fs')
  , path = require('path');

function create_file(client, key, i, callback) {
    client.upload(key + i, __dirname + '/auth_test.js', {index: i}, function() {
        if(++i !== 10) {
            create_file(client, key, i, callback);
        } else {
            callback();
        }
    });
};

var client = oss.createClient(config.getFileSystemConfig().oss)
  , checktime = (new Date()).getTime()
  , metas = {author: 'mk2', checktime: this.checktime}
  , key = '/tmp/test1/oss_api.pdf'
  , init = false;

module.exports = testCase({
    setUp: function(callback) {
        this.client = client;
        this.key = key;
        this.checktime = checktime;
        this.metas = metas;
//        var uploadfile = __dirname + '/../../doc/oss_api.pdf';
        var uploadfile = __dirname + '/client_test.js';
        var that = this;
        this.client.upload(this.key, uploadfile, this.metas, function(err, metas, headers) {
//            return create_file(client, '/tmp/test1/subdir2/file1', 0, function() {
//                callback();
//            });
            callback();
        });
    },
    tearDown: function(callback) {
        // clean up
        var that = this;
        that.client.info(that.key, function(err, metas) {
            if(err) {
                return callback();
            }
            that.client.delete(that.key, function(err) {
                callback(err);
            });
        });
    },
    list: function(test) {
        this.client.list('/tmp/test1/', function(err, contents, prefixs) {
            test.ifError(err);
            if(!err) {
                test.ok(prefixs.length > 0);
                var found = false;
                for(var i = 0, l = prefixs.length; i < l; i++) {
                    if(found = prefixs[i] === 'subdir1/') {
                        break;
                    }
                }
                test.ok(found);
                test.ok(contents.length > 0);
                found = false;
                for(var i = 0, l = contents.length; i < l; i++) {
                    if(found = contents[i].Key === 'oss_api.pdf') {
                        break;
                    }
                }
                test.ok(found);
            }
            test.done();
        });
    },
    listNotExits: function(test) {
        var notExits = ['/testNotExits/', '__NotExits', '/__NotExits', '/test/NotExits', '/test/NotExits/NotExits'];
        var count = 0, that = this;
        notExits.forEach(function(key) {
            that.client.list(key, function(err, contents, prefixs) {
                test.ifError(err);
                test.ok(contents.length === 0);
                test.ok(prefixs.length === 0);
                if(++count === notExits.length) {
                    test.done();
                }
            });
        });
    },
    listSync: function(test) {
        var that = this;
        test.doesNotThrow(function() {
            var datas = that.client.listSync('/tmp/test1');
            var prefixs = datas[1], contents = datas[0];
            test.ok(prefixs.length > 0);
            var found = false;
            for(var i = 0, l = prefixs.length; i < l; i++) {
                if(found = prefixs[i] === 'subdir1/') {
                    break;
                }
            }
            test.ok(found);
            test.ok(contents.length > 0);
            for(var i = 0, l = contents.length; i < l; i++) {
                if(found = contents[i].Key === 'oss_api.pdf') {
                    break;
                }
            }
            test.ok(found);
        });
        test.done();
    },
    info: function(test) {
        var that = this;
        that.client.info(this.key, function(err, metas, headers) {
            test.ifError(err);
            if(!err) {
                test.ok(metas);
                for(var k in metas) {
                    test.equal(metas[k], that.metas[k]);
                }
                test.ok(headers);
            }
            test.done();
        });
    },
    infoSync: function(test) {
        var that = this;
        test.doesNotThrow(function() {
            var datas = that.client.infoSync(that.key);
            var metas = datas[0], headers = datas[1];
            test.ok(metas);
            for(var k in metas) {
                test.equal(metas[k], that.metas[k]);
            }
            test.ok(headers);
        });
        test.done();
    },
    download: function(test) {
        var that = this;
        var tmpfile = '/tmp/test_oss_api.pdf';
        if(path.existsSync(tmpfile)) {
            fs.unlinkSync(tmpfile);
        }
        test.ok(!path.existsSync(tmpfile));
        that.client.download(this.key, tmpfile, function(err, metas, headers) {
            test.ifError(err);
            if(!err) {
                test.ok(fs.statSync(tmpfile).size > 0);
                for(var k in metas) {
                    test.equal(metas[k], that.metas[k]);
                }
                test.ok(headers);
            }
            test.done();
        });
    },
    downloadSync: function(test) {
        var that = this;
        var tmpfile = '/tmp/sync_test_oss_api.pdf';
        if(path.existsSync(tmpfile)) {
            fs.unlinkSync(tmpfile);
        }
        test.ok(!path.existsSync(tmpfile));
        test.doesNotThrow(function() {
            var datas = that.client.downloadSync(that.key, tmpfile);
            var metas = datas[0], headers = datas[1];
            test.ok(fs.statSync(tmpfile).size > 0);
            for(var k in metas) {
                test.equal(metas[k], that.metas[k]);
            }
            test.ok(headers);
        });
        test.done();
    },
    upload: function(test) {
        var that = this;
        var uploadfile = __dirname + '/../../../lib/filesystem/oss/client.js';
        var key = '/tmp/test/oss/client.js';
        that.client.upload(key, uploadfile, function(err) {
            test.ifError(err);
            if(!err) {
                that.client.info(key, function(err, metas, headers) {
                    test.ifError(err);
                    test.equal(Object.keys(metas).length, 0);
                    test.equal(parseInt(headers['content-length']), fs.statSync(uploadfile).size);
                    test.done();
                });
            } else {
                test.done();
            }
        });
    },
    uploadWithMetas: function(test) {
        var that = this;
        var uploadfile = __dirname + '/../../../lib/filesystem/oss/index.js';
        var key = '/tmp/test/oss/index_has_metas.js';
        that.client.upload(key, uploadfile, that.metas, function(err) {
            test.ifError(err);
            if(!err) {
                that.client.info(key, function(err, metas, headers) {
                    test.ifError(err);
                    for(var k in metas) {
                        test.equal(metas[k], that.metas[k]);
                    }
                    test.equal(parseInt(headers['content-length']), fs.statSync(uploadfile).size);
                    test.done();
                });
            } else {
                test.done();
            }
        });
    },
    'set and get': function(test) {
        var that = this;
        var key = '/tmp/foobar', set_data = 'bar ' + that.checktime;
        that.client.set(key, set_data, function(err) {
            test.ifError(err);
            that.client.get(key, function(err, data, metas, headers) {
                test.ifError(err);
                if(!err) {
                    test.ok(metas);
                    test.ok(headers);
                    test.equal(set_data, data.toString());
                }
                test.done();
            });
        });
    },
    'setSync and getSync': function(test) {
        var that = this;
        var key = '/tmp/foobar', set_data = 'bar ' + that.checktime;
        test.doesNotThrow(function() {
            that.client.setSync(key, set_data);
            var datas = that.client.getSync(key);
            var data = datas[0], metas = datas[1], headers = datas[2];
            test.ok(metas);
            test.ok(headers);
            test.equal(set_data, data.toString());
        });
        test.done();
        
    },
    'delete': function(test) {
        var that = this;
        that.client.info(that.key, function(err, metas) {
            test.ifError(err);
            for(var k in metas) {
                test.equal(metas[k], that.metas[k]);
            }
            that.client.delete(that.key, function(err) {
                test.ifError(err);
                that.client.info(that.key, function(err, metas) {
                    test.ok(err);
                    test.equal(err.status, 404);
                    test.equal(err.message, 'HTTP 404 Error');
                    test.done();
                });
            });
        });
    },
    'deleteSync': function(test) {
        var that = this;
        var datas = that.client.infoSync(that.key);
        var metas = datas[0], headers = datas[1];
        test.ok(metas);
        for(var k in metas) {
            test.equal(metas[k], that.metas[k]);
        }
        test.ok(headers);
        test.doesNotThrow(function() {
            that.client.deleteSync(that.key);
        });
        test.throws(function() {
            that.client.infoSync(that.key);
        });
        test.done();
    },
});

