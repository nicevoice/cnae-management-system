require('../../../lib/config').loadFromFile(__dirname + '/../../config.json');

var auth = require('../../../lib/filesystem/oss/auth');

var options = {
    method: 'put',
    headers: {
        'Content-Md5': 'c8fdb181845a4ca6b8fec737b3581d76',
        'Content-Type': 'text/html',
        Date: 'Thu, 17 Nov 2005 18:49:58 GMT',
        'X-OSS-magic': 'abracadabra',
        'X-OSS-meta-author': 'foo@bar.com'
    },
    path: '/quotes/nelson'
};
var appkey = '44CF9590006BF252F707', secret = 'OtxrzxIsfpFjA7SwPzILwy8Bw21TLhquhboDYROV';

module.exports = {
    sign: function(test) {
        var op = auth.sign(options, appkey, secret);
        test.equal(op.headers['Authorization'], 'OSS 44CF9590006BF252F707:u5PsYM7ztEH+FiDbY6TKGOYRYxo=');
        test.done();
    }
};