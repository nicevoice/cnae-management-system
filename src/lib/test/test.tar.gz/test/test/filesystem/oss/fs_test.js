require('../../../lib/config').loadFromFile(__dirname + '/../../config.json');

var testCase = require('nodeunit').testCase;
var fs = require('fs')
  , nfs = require('../../../lib/filesystem/oss').fs
  , exec = require('child_process').exec;
nfs.__client._request_timeout = 2000;
function createfile(path, data, callback) {
    nfs.open(path, 'w', function(err, fd) {
        if(!Buffer.isBuffer(data)) {
            data = new Buffer(data);
        }
        nfs.write(fd, data, 0, data.length, 0, function(err) {
            
        });
    });
};

module.exports = testCase({
    setUp: function(callback) {
        this.dir = '/tmp/oss_test_not_exists/nfs_mkdir_test';
        this.dirExists = '/tmp/oss_test_exists/subdir1/subdir2';
        this.file = '/tmp/oss_test_exists/fs_test_file.txt';
        var that = this;
        var createfile = function(cb) {
            nfs.open(that.file, 'w', function(err, fd) {
                var data = new Buffer('test abcd');
                nfs.write(fd, data, 0, data.length, 0, function(err, bytes) {
                    nfs.close(fd, function(err) {
                        nfs.statSync(that.file);
                        cb();
                    });
                });
            });
        };
        nfs.mkdir(that.dirExists, function(err) {
            createfile(callback);
        });
    },
    tearDown: function(callback) {
        var that = this;
        exec('rm -rf /tmp/oss_test_not_exists /tmp/oss_test_exists', function(err) {
            nfs.rmdir(that.dir, function() {
                callback(err);
            });
        });
    },
    _mkdirs: function(test) {
        var path = '/tmp/a/b/c/d/e/f';
        nfs._mkdirs(path, '0755', function(err) {
            test.ifError(err);
            test.ok(fs.statSync(path));
            test.done();
        });
    },
    _mkdirsSync: function(test) {
        var path = '/tmp/a2/b/c/d/e/f';
        nfs._mkdirsSync(path, '0755');
        fs.statSync(path);
        test.done();
    },
    resolvepath: function(test) {
        var paths = [
             [__dirname + '/.', __dirname],
             [__dirname + '/./', __dirname],
             [__dirname + '/./abc/', __dirname + '/abc'],
             ['/a/b/c/d/', '/a/b/c/d'],
             ['/a', '/a'],
             ['/a/', '/a'],
             ['/a/b/..', '/a'],
             ['/a/b/../', '/a'],
             ['/a/b/.', '/a/b'],
             ['/a/b/abc.txt', '/a/b/abc.txt'],
             ['/a/b/../abc.txt', '/a/abc.txt'],
        ];
        for(var i = 0, l = paths.length; i < l; i++) {
            var path = paths[i];
            var p = nfs.resolvepath(path[0]);
            test.equal(p, path[1], path[0]);
            test.ok(p[p.length - 1] !== '/');
        }
        test.equal(nfs.resolvepath('/'), '/');
        test.done();
    },
    mkdir: function(test) {
        var that = this;
        nfs.mkdir(that.dir, function(err) {
            test.ifError(err);
            if(err) {
               return test.done(); 
            }
            nfs.stat(that.dir, function(err, stats) {
                test.ifError(err);
                test.strictEqual(stats.mode, 0755);
                test.ok(stats.mtime);
                test.ok(stats.atime);
                test.ok(stats.ctime);
                test.ok(stats.isDirectory());
                test.done();
            });
        });
    },
    mkdirExists: function(test) {
        var path = '/tmp/oss/exits' + new Date().getTime();
        nfs.mkdir(path, function(err) {
            test.ifError(err);
            if(err) {
                return test.done();
            }
            nfs.mkdir(path, function(err) {
                test.ok(err);
                test.equal(err.code, 'EEXIST');
                test.equal(err.message.indexOf('EEXIST, File exists'), 0);
                test.done();
            });
        });
    },
    mkdirSync: function(test) {
        var that = this;
        test.doesNotThrow(function() {
            nfs.mkdirSync(that.dir);
        });
        test.throws(function() {
            nfs.mkdirSync(that.dir);
        });
        test.done();
    },
    rmdir: function(test) {
        var that = this;
        nfs.mkdir(that.dir, function(err) {
            test.ifError(err);
            nfs.rmdir(that.dir, function(err) {
                test.ifError(err);
                test.done();
            });
        });
    },
    rmdirNotExists: function(test) {
        var that = this;
        nfs.rmdir(that.dir, function(err) {
            test.ifError(err);
            test.done();
        });
    },
    rmdirNotEmpty: function(test) {
        nfs.rmdir('/tmp', function(err) {
            test.ok(err);
            test.equal(err.code, 'ENOTEMPTY');
            test.equal(err.message.indexOf('ENOTEMPTY, Directory not empty'), 0);
            test.done();
        });
    },
    'rmdir use in remove file': function(test) {
        var that = this;
        nfs.rmdir(that.file, function(err) {
            test.ok(err);
            test.equal(err.code, 'EPERM');
            test.equal(err.message.indexOf('EPERM, Operation not permitted'), 0);
            test.done();
        });
    },
    rmdirSync: function(test) {
        var that = this;
        nfs.mkdirSync(that.dir);
        test.doesNotThrow(function() {
            nfs.rmdirSync(that.dir);
        });
        // not exists
        test.doesNotThrow(function(err) {
            nfs.rmdirSync(that.dir);
        });
        // not empty
        test.throws(function(err) {
            nfs.rmdirSync('/tmp/');
        });
        test.done();
    },
    readdir: function(test) {
        nfs.readdir('/tmp/oss_test_exists', function(err, files) {
            test.ifError(err);
            if(err) {
                return test.done();
            }
            test.ok(files instanceof Array && files.length > 0);
            var founddir = false, foundfile = false;
            for(var i = 0, l = files.length; i < l; i++) {
                if(files[i] === 'subdir1/') {
                    founddir = true;
                }
                if(files[i] === 'fs_test_file.txt') {
                    foundfile = true;
                }
            }
            test.ok(founddir);
            test.ok(foundfile);
            test.done();
        });
    },
    readdirSync: function(test) {
        test.doesNotThrow(function() {
            var files = nfs.readdirSync('/tmp/oss_test_exists');
            test.ok(files instanceof Array && files.length > 0);
            var founddir = false, foundfile = false;
            for(var i = 0, l = files.length; i < l; i++) {
                if(files[i] === 'subdir1/') {
                    founddir = true;
                }
                if(files[i] === 'fs_test_file.txt') {
                    foundfile = true;
                }
            }
            test.ok(founddir);
            test.ok(foundfile);
        });
        test.done();
    },
    open: function(test) {
        var that = this;
        nfs.open(that.file, 'r', function(err, fd) {
            test.ifError(err);
            if(err) {
                return test.done();
            }
            test.ok(fd);
            nfs.close(fd, function(err) {
                test.ifError(err);
                test.done();
            });
        });
    },
    openNotExists: function(test) {
        nfs.open('abc_not_exists.txt', 'r+', function(err, fd) {
            test.ok(err);
            test.ok(err.message.indexOf('No such file or directory') >= 0);
            test.equal(err.code, 'ENOENT');
            test.ok(!fd);
            test.done();
        });
    },
    openSync: function(test) {
        var that = this;
        test.doesNotThrow(function() {
            var fd = nfs.openSync(that.file, 'r');
            test.ok(fd);
            nfs.closeSync(fd);
        });
        try {
            nfs.openSync('abc_not_exists.txt', 'r');
        } catch(err) {
            test.ok(err);
            test.ok(err.message.indexOf('No such file or directory') >= 0);
            test.equal(err.code, 'ENOENT');
            test.done();
        }
    },
    write: function(test) {
        var that = this;
        nfs.open(that.file, 'w', function(err, fd) {
            test.ifError(err);
            if(err) {
                return test.done();
            }
            var data = new Buffer('abc');
            nfs.write(fd, data, 0, data.length, null, function(err, written) {
                test.ifError(err);
                if(err) {
                    return test.done();
                }
                test.equal(data.length, written);
                nfs.close(fd, function(err) {
                    test.ifError(err);
                    if(err) {
                        return test.done();
                    }
                    test.done();
                });
            });
        });
    },
    'write 0 byte': function(test) {
        var that = this;
        var old_stats = nfs.statSync(that.file);
        nfs.open(that.file, 'w', function(err, fd) {
            test.ifError(err);
            if(err) {
                return test.done();
            }
            var data = new Buffer('abc');
            nfs.write(fd, data, 0, 0, null, function(err, written) {
                test.ifError(err);
                if(err) {
                    return test.done();
                }
                test.equal(0, written);
                nfs.close(fd, function(err) {
                    test.ifError(err);
                    if(err) {
                        return test.done();
                    }
                    var now_stats = nfs.statSync(that.file);
                    test.equal(now_stats.size, 0);
//                    test.ok(now_stats.mtime.getTime() > old_stats.mtime.getTime());
                    test.done();
                });
            });
        });
    },
    'append 0 byte': function(test) {
        var that = this;
        var old_stats = nfs.statSync(that.file);
        nfs.open(that.file, 'a', function(err, fd) {
            test.ifError(err);
            if(err) {
                return test.done();
            }
            var data = new Buffer('abc');
            nfs.write(fd, data, 0, 0, null, function(err, written) {
                test.ifError(err);
                if(err) {
                    return test.done();
                }
                test.equal(0, written);
                nfs.close(fd, function(err) {
                    test.ifError(err);
                    if(err) {
                        return test.done();
                    }
                    var now_stats = nfs.statSync(that.file);
                    test.equal(now_stats.size, old_stats.size);
                    test.equal(now_stats.mtime.getTime(), old_stats.mtime.getTime());
                    test.done();
                });
            });
        });
    },
    writeSync: function(test) {
        var that = this;
        test.doesNotThrow(function() {
            var fd = nfs.openSync(that.file, 'w');
            var data = new Buffer('abc');
            var written = nfs.writeSync(fd, data, 0, data.length, null);
            test.equal(data.length, written);
            nfs.closeSync(fd);
        });
        test.done();
    },
    unlink: function(test) {
        var that = this;
        nfs.unlink(that.file, function(err) {
            test.ifError(err);
            if(err) {
                return test.done();
            }
            nfs.stat(that.file, function(err, stat) {
                test.ok(err);
                test.equal(err.code, 'ENOENT');
                test.equal(err.message.indexOf('ENOENT, No such file or directory'), 0);
                test.done();
            });
        });
    },
    unlinkError: function(test) {
        var that = this;
        nfs.unlink('/tmp/test1/__notexists.txt', function(err) {
            test.ok(err);
            test.equal(err.code, 'ENOENT');
            test.equal(err.message.indexOf('ENOENT, No such file or directory'), 0);
            // unlink dir error
            nfs.mkdir(that.dir, 0755, function(err) {
                test.ifError(err);
                if(err) {
                    return test.done();
                }
                nfs.unlink(that.dir, function(err) {
                    test.ok(err);
                    test.equal(err.code, 'EPERM');
                    test.equal(err.message.indexOf('EPERM, Operation not permitted'), 0);
                    test.done();
                });
            });
        });
    },
    unlinkSync: function(test) {
        var that = this;
        nfs.statSync(that.file);
        nfs.unlinkSync(that.file);
        nfs.stat(that.file, function(err, stat) {
            test.ok(err);
            test.equal(err.code, 'ENOENT');
            test.equal(err.message.indexOf('ENOENT, No such file or directory'), 0);
            test.done();
        });
    },
    unlinkSyncError: function(test) {
        var that = this;
        nfs.unlinkSync(that.file);
        try {
            nfs.unlinkSync(that.file);
        } catch(err) {
            test.ok(err);
            test.equal(err.code, 'ENOENT');
            test.equal(err.message.indexOf('ENOENT, No such file or directory'), 0);
            test.done();
        }
    },
    rename: function(test) {
        var that = this, tofile = this.file + '.to.new';
        var old_stats = nfs.statSync(that.file);
        nfs.rename(that.file, tofile, function(err) {
            test.ifError(err);
            if(err) {
                return test.done();
            }
            nfs.stat(tofile, function(err, stats) {
                test.ifError(err);
                if(err) {
                    return test.done();
                }
                test.equal(stats.size, old_stats.size);
                test.ok(stats.isFile());
                nfs.stat(that.file, function(err, stats) {
                    test.ok(err);
                    test.equal(err.code, 'ENOENT');
                    test.ok(!stats);
                    test.done();
                });
            });
        });
    },
    renameDirError: function(test) {
        var that = this, tofile = this.dirExists + '.to.new';
        nfs.rename(that.dirExists, tofile, function(err) {
            test.ok(err);
            test.equal(err.message.indexOf('Only support file rename'), 0);
            test.done();
        });
    },
    renameSync: function(test) {
        var that = this, tofile = this.file + '.to.new';
        var old_stats = nfs.statSync(that.file);
        nfs.renameSync(that.file, tofile);
        var stats = nfs.statSync(tofile);
        test.equal(stats.size, old_stats.size);
        test.ok(stats.isFile());
        try {
            nfs.statSync(that.file);
        } catch(err) {
            test.ok(err);
            test.equal(err.code, 'ENOENT');
        }
        test.done();
    },
    renameSyncDirError: function(test) {
        var that = this, tofile = this.dirExists + '.to.new';
        try {
            nfs.renameSync(that.dirExists, tofile);
        } catch(err) {
            test.ok(err);
            test.equal(err.message.indexOf('Only support file rename'), 0);
            test.done();
        }
    },
});