//
//var curl = require('node_curl');
//var testCase = require('nodeunit').testCase;
//
//module.exports = testCase({
//    setUp: function(callback) {
//        callback();
//    },
//    tearDown: function(callback) {
//        callback();
//    },
//    request: function(test) {
//        var req = curl.request({url: 'http://weibo.com/'});
//        var res = req.end();
//        test.ok(res);
//        test.ok(res.headers);
//        test.ok(res.ip);
//        test.ok(res.data.length > 0);
//        test.strictEqual(res.statusCode, 200);
//        test.done();
//    },
//    requestHEAD: function(test) {
//        var req = curl.request({url: 'http://weibo.com/', method: 'head'});
//        var res = req.end();
//        test.ok(res);
//        test.ok(res.headers);
//        test.ok(res.ip);
//        test.strictEqual(res.data.length, 0);
//        test.strictEqual(res.statusCode, 200);
//        test.done();
//    },
//    requestPOST: function(test) {
//        var data = new Buffer('abc');
////        var headers = {'Content-Length': data.length};
//        var req = curl.request({url: 'http://weibo.com/', method: 'post'});
//        req.write(data);
//        var res = req.end();
//        test.ok(res);
//        test.ok(res.headers);
//        test.ok(res.ip);
//        test.ok(res.data.length > 0);
//        test.strictEqual(res.statusCode, 200);
//        test.done();
//    },
//    requestPUT: function(test) {
//        var data = new Buffer('abc');
////        var headers = {'Content-Length': data.length};
//        var req = curl.request({url: 'http://weibo.com/', method: 'put'});
//        req.write(data);
//        var res = req.end();
//        test.ok(res);
//        test.ok(res.headers);
//        test.ok(res.ip);
//        test.ok(res.data.length > 0);
//        test.strictEqual(res.statusCode, 200);
//        test.done();
//    }
//});
