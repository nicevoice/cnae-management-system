
require('../../lib/config').loadFromFile(__dirname + '/../config.json');

var testCase = require('nodeunit').testCase;
var fs = require('../../lib/filesystem')
  , _fs = require('fs');

module.exports = testCase({
    setUp: function(callback) {
        this.localfile = __dirname + '/oss/foo.txt';
        _fs.statSync(this.localfile);
        
        this.savefile = this.localfile + '.write.txt';
        
        this.remotefile = this.localfile + '.remote.txt';
        fs.writeFileSync(this.remotefile, 'abc');
        fs.statSync(this.remotefile);
        
        callback();
    },
    tearDown: function(callback) {
        var that = this;
        fs.unlink(that.savefile, function() {
            fs.unlink(that.remotefile, function() {
                callback();
            });
        });
    },
    'fs engine': function(test) {
        test.equal(fs.__name, 'oss');
        test.ok(fs.__engine);
        test.done();
    },
    readFile: function(test) {
        var that = this;
        fs.readFile(that.remotefile, function(err, data) {
            test.ifError(err);
            if(err) {
                return test.done();
            }
            test.equal(data.toString(), 'abc');
            test.done();
        });
    },
    readFileSync: function(test) {
        var that = this;
        test.doesNotThrow(function() {
            var data = fs.readFileSync(that.remotefile);
            test.equal(data.toString(), 'abc');
        });
        test.done();
    },
    createReadStream: function(test) {
        var filename = this.remotefile, readed = 0;
        try {
            _fs.unlinkSync(filename);
        } catch(e) {
            
        }
        var rs = fs.createReadStream(filename);
        rs.on('data', function(chunk) {
            readed += chunk.length;
        }).on('end', function() {
            fs.stat(filename, function(err, stats) {
                test.ifError(err);
                test.equal(stats.size, readed);
                test.done();
            });
        }).on('error', function(err) {
            test.ifError(err);
            test.done();
        });
    },
    createReadStreamError: function(test) {
        var filename = __dirname + '/oss/foo.txt.write.txt.error';
        var rs = fs.createReadStream(filename);
        rs.on('error', function(err) {
            test.ok(err);
            test.equal(err.code, 'ENOENT');
            test.equal(err.message.indexOf('ENOENT, No such file or directory'), 0);
            test.done();
        });
    },
    createWriteStream: function(test) {
        var that = this;
        var size = _fs.statSync(that.localfile).size;
        var ws = fs.createWriteStream(that.savefile)
          , rs = _fs.createReadStream(that.localfile), readed = 0;
        test.ok(ws);
        rs.on('data', function(chunk) {
            readed += chunk.length;
            ws.write(chunk);
        }).on('end', function() {
            ws.end();
        });
        ws.on('error', function(err) {
            test.ifError(err);
            test.ok(!err);
            test.done();
        });
        ws.on('close', function() {
            test.equal(size, readed);
            test.equal(size, ws.bytesWritten);
            fs.stat(that.savefile, function(err, stats) {
                test.ifError(err);
                test.equal(stats.size, size);
                test.ok(stats.isFile());
                var local_stats = _fs.statSync(that.savefile);
                test.strictEqual(local_stats.mtime.toGMTString(), stats.mtime.toGMTString());
                test.done();
            });
        });
    },
});
