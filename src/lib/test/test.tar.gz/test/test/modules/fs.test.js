require('../../lib/config').loadFromFile(__dirname + '/../config.json');

var config = require('../../lib/config')
  , path = require('path');

var fs = require('../../lib/modules/fs');

var appinfo = require('../../lib/appinfo');

var appdir = appinfo.dirname, parentdir = path.dirname(appdir);

//console.log(appinfo, base)
//throw appinfo
var error_paths = [
    'abc', '/usr', '/', '',
    parentdir + '/', parentdir, parentdir + '/helloworl/ttt',
];

var error_dirs = [
   'abc', '/usr/foo', '/', '',
   parentdir + '/', parentdir, parentdir + '/helloworl/ttt',
];

var success_paths = [
    appdir + '/helloworld/1', appdir + '/helloworld/file', appdir + '/helloworld/1332/sdfsdf/www.f',
    appdir + '/index.js', '/tmp/abc.txt'
];

var success_dirs = [
   appdir + '/helloworld', appdir + '/helloworld/', appdir + '/helloworld/dddir', appdir + '/helloworld/1332/sdfsdf/wwwdir',
   appdir + '/index.js/dir', '/tmp/abc.txt/dir', '/tmp'
];

function create_done(total, test) {
    return function(p) {
        if(--total === 0) {
            test.done();
        }
    };
};

var tests = {
	'fs.open': function(test) {
	    var total = error_paths.length + success_paths.length;
	    test.expect(total);
	    var done = create_done(total, test);
		error_paths.forEach(function(p) {
			fs.open(p, 'a', function(err) {
				test.ok(err && err.not_in_app, p);
				done(p);
			});
		});
		success_paths.forEach(function(p) {
			fs.open(p, 'a', function(err) {
				test.ok(!err || !err.not_in_app, p);
				done(p);
			});
		});
	},
	'fs.openSync': function(test) {
		error_paths.forEach(function(p) {
			try {
				fs.openSync(p, 'a');
				test.ok(false, p);
			} catch(err) {
				test.ok(err, p);
			}
		});
		success_paths.forEach(function(p) {
			try {
				fs.openSync(p, 'w');
				test.ok(true, p);
			} catch(err) {
				test.ok(!err || !err.not_in_app, p);
			}
		});
		test.done();
	},
	'fs.mkdir': function(test) {
		error_dirs.forEach(function(p) {
			fs.mkdir(p, '0755', function(err) {
				test.ok(err && err.not_in_app, p);
			});
		});
		success_dirs.forEach(function(p) {
			fs.mkdir(p, '0755', function(err) {
				test.ok(!err || !err.not_in_app, p);
			});
		});
		test.done();
	},
	'fs.mkdirSync': function(test) {
	    error_dirs.forEach(function(p) {
			try {
				fs.mkdirSync(p, '0755');
				test.ok(false, p);
			} catch(err) {
				test.ok(err.not_in_app, p);
			}
		});
		success_dirs.forEach(function(p) {
			try {
				fs.mkdirSync(p, '0755');
				test.ok(true, p);
			} catch(err) {
				test.ok(!err.not_in_app, p);
			}
		});
		test.done();
	},
	'fs.rmdir': function(test) {
	    error_dirs.forEach(function(p) {
			fs.rmdir(p, function(err) {
				test.ok(err && err.not_in_app, p);
			});
		});
		success_dirs.forEach(function(p) {
			fs.rmdir(p, function(err) {
				test.ok(!err || !err.not_in_app, p);
			});
		});
		test.done();
	},
	'fs.rmdirSync': function(test) {
	    error_dirs.forEach(function(p) {
			try {
				fs.rmdirSync(p);
				test.ok(false, p);
			} catch(err) {
				test.ok(err.not_in_app, p);
			}
		});
		success_dirs.forEach(function(p) {
			try {
				fs.rmdirSync(p);
				test.ok(true, p);
			} catch(err) {
				test.ok(!err.not_in_app, p);
			}
		});
		test.done();
	},
//	'fs.readdir': function(test) {
//		error_paths.forEach(function(p) {
//			fs.readdir(p, function(err) {
//				test.ok(err && err.not_in_app, p);
//			});
//		});
//		success_paths.forEach(function(p) {
//			fs.readdir(p, function(err) {
//				test.ok(!err || !err.not_in_app, p);
//			});
//		});
//		test.done();
//	},
//	'fs.readdirSync': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.readdirSync(p);
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				fs.readdirSync(p);
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//	'fs.lstat': function(test) {
//		error_paths.forEach(function(p) {
//			fs.lstat(p, function(err) {
//				test.ok(err && err.not_in_app, p);
//			});
//		});
//		success_paths.forEach(function(p) {
//			fs.lstat(p, function(err) {
//				test.ok(!err || !err.not_in_app, p);
//			});
//		});
//		test.done();
//	},
//	'fs.lstatSync': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.lstatSync(p);
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				fs.lstatSync(p);
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//	'fs.stat': function(test) {
//		error_paths.forEach(function(p) {
//			fs.stat(p, function(err) {
//				test.ok(err && err.not_in_app, p);
//			});
//		});
//		success_paths.forEach(function(p) {
//			fs.stat(p, function(err) {
//				test.ok(!err || !err.not_in_app, p);
//			});
//		});
//		test.done();
//	},
//	'fs.statSync': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.statSync(p);
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				fs.statSync(p);
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//	'fs.readlink': function(test) {
//		error_paths.forEach(function(p) {
//			fs.readlink(p, function(err) {
//				test.ok(err && err.not_in_app, p);
//			});
//		});
//		success_paths.forEach(function(p) {
//			fs.readlink(p, function(err) {
//				test.ok(!err || !err.not_in_app, p);
//			});
//		});
//		test.done();
//	},
//	'fs.readlinkSync': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.readlinkSync(p);
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				fs.readlinkSync(p);
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//	'fs.unlink': function(test) {
//		error_paths.forEach(function(p) {
//			fs.unlink(p, function(err) {
//				test.ok(err && err.not_in_app, p);
//			});
//		});
//		success_paths.forEach(function(p) {
//			fs.unlink(p, function(err) {
//				test.ok(!err || !err.not_in_app, p);
//			});
//		});
//		test.done();
//	},
//	'fs.unlinkSync': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.unlinkSync(p);
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				fs.unlinkSync(p);
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//	'fs.lchmod': function(test) {
//		if(fs.lchmod) {
//			error_paths.forEach(function(p) {
//				fs.lchmod(p, function(err) {
//					test.ok(err && err.not_in_app, p);
//				});
//			});
//			success_paths.forEach(function(p) {
//				fs.lchmod(p, function(err) {
//					test.ok(!err || !err.not_in_app, p);
//				});
//			});
//		}
//		test.done();
//	},
//	'fs.lchmodSync': function(test) {
//		if(fs.lchmodSync) {
//			error_paths.forEach(function(p) {
//				try {
//					fs.lchmodSync(p);
//					test.ok(false, p);
//				} catch(err) {
//					test.ok(err.not_in_app, p);
//				}
//			});
//			success_paths.forEach(function(p) {
//				try {
//					fs.lchmodSync(p);
//					test.ok(true, p);
//				} catch(err) {
//					test.ok(!err.not_in_app, p);
//				}
//			});
//		}
//		test.done();
//	},
//	'fs.chmod': function(test) {
//		error_paths.forEach(function(p) {
//			fs.chmod(p, '0666', function(err) {
//				test.ok(err && err.not_in_app, p);
//			});
//		});
//		success_paths.forEach(function(p) {
//			fs.chmod(p, '0666', function(err) {
//				test.ok(!err || !err.not_in_app, p);
//			});
//		});
//		test.done();
//	},
//	'fs.chmodSync': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.chmodSync(p, '0666');
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				fs.chmodSync(p, '0666');
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//	'fs.lchown': function(test) {
//		if(fs.lchown) {
//			error_paths.forEach(function(p) {
//				fs.lchown(p, '0666', function(err) {
//					test.ok(err && err.not_in_app, p);
//				});
//			});
//			success_paths.forEach(function(p) {
//				fs.lchown(p, '0666', function(err) {
//					test.ok(!err || !err.not_in_app, p);
//				});
//			});
//		}
//		test.done();
//	},
//	'fs.lchownSync': function(test) {
//		if(fs.lchownSync) {
//			error_paths.forEach(function(p) {
//				try {
//					fs.lchownSync(p, '0666');
//					test.ok(false, p);
//				} catch(err) {
//					test.ok(err.not_in_app, p);
//				}
//			});
//			success_paths.forEach(function(p) {
//				try {
//					fs.lchownSync(p, '0666');
//					test.ok(true, p);
//				} catch(err) {
//					test.ok(!err.not_in_app, p);
//				}
//			});
//		}
//		test.done();
//	},
//	'fs.chown': function(test) {
//		error_paths.forEach(function(p) {
//			fs.chown(p, 1, function(err) {
//				test.ok(err && err.not_in_app, p);
//			});
//		});
//		success_paths.forEach(function(p) {
//			fs.chown(p, 1, 1, function(err) {
//				test.ok(!err || !err.not_in_app, p);
//			});
//		});
//		test.done();
//	},
//	'fs.chownSync': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.chownSync(p, 1);
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				fs.chownSync(p, 1);
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//	'fs.realpath': function(test) {
//		error_paths.forEach(function(p) {
//			fs.realpath(p, function(err) {
//				test.ok(err && err.not_in_app, p);
//			});
//		});
//		success_paths.forEach(function(p) {
//			fs.realpath(p, function(err) {
//				test.ok(!err || !err.not_in_app, p);
//			});
//		});
//		test.done();
//	},
//	'fs.realpathSync': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.realpathSync(p);
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				fs.realpathSync(p);
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//	'fs.readFile': function(test) {
//		error_paths.forEach(function(p) {
//			fs.readFile(p, function(err) {
//				test.ok(err && err.not_in_app, p);
//			});
//		});
//		success_paths.forEach(function(p) {
//			fs.readFile(p, function(err) {
//				test.ok(!err || !err.not_in_app, p);
//			});
//		});
//		test.done();
//	},
//	'fs.readFileSync': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.readFileSync(p);
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				fs.readFileSync(p);
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//	'fs.utimes': function(test) {
//		if(fs.utimes) {
//			error_paths.forEach(function(p) {
//				fs.utimes(p, new Date, new Date, function(err) {
//					test.ok(err && err.not_in_app, p);
//				});
//			});
//			success_paths.forEach(function(p) {
//				fs.utimes(p, new Date, new Date, function(err) {
//					test.ok(!err || !err.not_in_app, p);
//				});
//			});
//		}
//		test.done();
//	},
//	'fs.utimesSync': function(test) {
//		if(fs.utimesSync) {
//			error_paths.forEach(function(p) {
//				try {
//					fs.utimesSync(p, new Date, new Date);
//					test.ok(false, p);
//				} catch(err) {
//					test.ok(err.not_in_app, p);
//				}
//			});
//			success_paths.forEach(function(p) {
//				try {
//					fs.utimesSync(p, new Date, new Date);
//					test.ok(true, p);
//				} catch(err) {
//					test.ok(!err.not_in_app, p);
//				}
//			});
//		}
//		test.done();
//	},
//	'fs.writeFile': function(test) {
//		error_paths.forEach(function(p) {
//			fs.writeFile(p, 'test', function(err) {
//				test.ok(err && err.not_in_app, p);
//			});
//		});
//		success_paths.forEach(function(p) {
//			fs.writeFile(p, 'test', function(err) {
//				test.ok(!err || !err.not_in_app, p);
//			});
//		});
//		test.done();
//	},
//	'fs.writeFileSync': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.writeFileSync(p);
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				fs.writeFileSync(p);
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//
//	'fs.rename': function(test) {
//		error_paths.forEach(function(p) {
//			fs.rename(p, p + '1', function(err) {
//				test.ok(err && err.not_in_app, p);
//			});
//		});
//		success_paths.forEach(function(p) {
//			fs.rename(p, p + '2', function(err) {
//				test.ok(!err || !err.not_in_app, p);
//			});
//		});
//		test.done();
//	},
//	'fs.renameSync': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.renameSync(p, p + '3');
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				fs.renameSync(p, p + '4');
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//	'fs.symlink': function(test) {
//		error_paths.forEach(function(p) {
//			fs.symlink(p, p + '1', function(err) {
//				test.ok(err && err.not_in_app, p);
//			});
//		});
//		success_paths.forEach(function(p) {
//			fs.symlink(p, p + '2', function(err) {
//				test.ok(!err || !err.not_in_app, p);
//			});
//		});
//		test.done();
//	},
//	'fs.symlinkSync': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.symlinkSync(p, p + '3');
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				fs.symlinkSync(p, p + '4');
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//	'fs.link': function(test) {
//		error_paths.forEach(function(p) {
//			fs.link(p, p + '1', function(err) {
//				test.ok(err && err.not_in_app, p);
//			});
//		});
//		success_paths.forEach(function(p) {
//			fs.link(p, p + '2', function(err) {
//				test.ok(!err || !err.not_in_app, p);
//			});
//		});
//		test.done();
//	},
//	'fs.linkSync': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.linkSync(p, p + '3');
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				fs.linkSync(p, p + '4');
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//
//	'fs.watchFile': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.watchFile(p);
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				fs.watchFile(p);
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//
//	'fs.unwatchFile': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.unwatchFile(p);
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				fs.unwatchFile(p);
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//
//	'fs.createReadStream': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.createReadStream(p);
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				var s = fs.createReadStream(p);
//				s.on('error', function(err) {
////					console.log(err)
//				});
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//
//	'fs.ReadStream': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				new fs.ReadStream(p);
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				var s = new fs.ReadStream(p);
//				s.on('error', function(err) {
////					console.log(err)
//				});
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//
//	'fs.createWriteStream': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				fs.createWriteStream(p);
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				var s = fs.createWriteStream(p);
//				s.on('error', function(err) {
////					console.log(err)
//				});
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
//
//	'fs.WriteStream': function(test) {
//		error_paths.forEach(function(p) {
//			try {
//				new fs.WriteStream(p);
//				test.ok(false, p);
//			} catch(err) {
//				test.ok(err.not_in_app, p);
//			}
//		});
//		success_paths.forEach(function(p) {
//			try {
//				var s = new fs.WriteStream(p);
//				s.on('error', function(err) {
////					console.log(err)
//				});
//				test.ok(true, p);
//			} catch(err) {
//				test.ok(!err.not_in_app, p);
//			}
//		});
//		test.done();
//	},
};

module.exports = tests;