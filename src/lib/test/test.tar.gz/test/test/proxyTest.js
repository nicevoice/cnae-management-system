/* vim: set expandtab tabstop=4 shiftwidth=4 foldmethod=marker: */

var TestCase	= require('nodeunit').testCase;
var Proxy		= require('../lib/proxy.js');
var Net		 = require('net');
var File		= require('fs');
var Config = require('../lib/config');
Config.loadFromFile(__dirname + '/config.json');

module.exports	= TestCase({
	setUp	: function(callback) {
		callback();
	},

	tearDown : function(callback){
		callback();
	},

	/* {{{ test_should_http_proxy_parse_works_fine() */
	test_should_http_proxy_parse_works_fine : function(test) {
		var proxy   = Proxy.create(__dirname + '/config.json');
		var req  = proxy.parse(File.readFileSync(__dirname + '/http/single_package.txt'));
		test.equal(req.header_end_pos, 495);
		test.equal(req.headers.host, 'edp2.corp.alimama.com:10023');
		test.equal(req.headers['content-length'], 13);
//		test.equal('GET', result.type);
//		test.equal('/a/b.php?c=1', result.path);
//		test.equal('edp2.corp.alimama.com:10023', result.head.Host);
//		test.equal('a=b&a[1]=2313', result.body.toString().trim());
		test.done();
	},
	/* }}} */

	/* {{{ test_should_default_proxy_appname_works_fine() */
	test_should_default_proxy_appname_works_fine	: function(test) {
		var proxy   = Proxy.create(__dirname + '/config.json');

		test.equal('pengchun', proxy.appname('pengchun.aaa.com'));
		test.equal('www', proxy.appname('www.aaa.com'));
		test.equal('', proxy.appname('a.bbb.com'));
		test.done();
	},
	/* }}} */

	/* {{{ test_should_bad_http_request_return_400_works_fine() */
	test_should_bad_http_request_return_400_works_fine   : function(test) {
		var proxy   = Proxy.create(__dirname + '/config.json');
		proxy.dispatch(18081);

		setTimeout(function() {
			var client  = Net.createConnection(18081, 'localhost');
			client.on('data', function(data) {
				var res = data.toString().split('\n');
				test.equal('HTTP/1.1 400 Bad Request', res.shift().trim());
				client.end();
				proxy.shutdown();
				test.done();
			});
			client.write('i am bad request');
		}, 100);
	},
	/* }}} */

	/* {{{ test_should_unregistered_app_return_404_works_fine() */
	test_should_unregistered_app_return_404_works_fine  : function(test) {
		var proxy   = Proxy.create(__dirname + '/config.json');
		proxy.dispatch(18081);

		setTimeout(function() {
			var client  = Net.createConnection(18081, 'localhost');
			client.on('data', function(data) {
				var res = data.toString().split('\n');
				test.equal('HTTP/1.1 404 Not Found', res.shift().trim());
				client.end();
				proxy.shutdown();
				test.done();
			});
			client.write('GET / HTTP/1.1\r\nHost:app2.aaa.com:18081\r\n');
		}, 100);
	},
	/* }}} */

	/* {{{ test_should_app_return_504_when_timeout_works_fine() */
	test_should_app_return_504_when_timeout_works_fine	: function(test) {
		test.done();
		return;
		var proxy   = Proxy.create(__dirname + '/config.json');
		proxy.dispatch(18081);
		proxy.register('app2', __dirname + '/proxy_test.sock');

		var server  = Net.createServer(function(socket) {
			socket.on('error', function(e) {
				console.log(e);
			});
			socket.on('data', function(data) {
				setTimeout(function() {
					try {
						socket.write(data);
					} catch (e) {}
				}, 1100);
			});
		});
		server.listen(__dirname + '/proxy_test.sock');

		setTimeout(function() {
			var client  = Net.createConnection(18081, 'localhost');
			client.on('data', function(data) {
				var res = data.toString().split('\n');
				test.equal('HTTP/1.1 504 Gateway Time-out', res.shift().trim());
				client.end();
				server.close();
				proxy.shutdown();
				test.done();
			});
			client.write('GET / HTTP/1.1\r\nHost: app2.aaa.com:18081\r\n');
		}, 100);
	},
	/* }}} */

	/* {{{ test_should_registered_app_return_200_works_fine() */
	test_should_registered_app_return_200_works_fine	: function(test) {
		var proxy   = Proxy.create(__dirname + '/config.json');
		proxy.dispatch(18081);
		proxy.register('app1', __dirname + '/proxy_test.sock');

		var server  = Net.createServer(function(socket) {
			socket.on('error', function(e) {
			});
			socket.on('data', function(data) {
				socket.write(data);
			});
		});
		server.listen(__dirname + '/proxy_test.sock');

		setTimeout(function() {
			var client  = Net.createConnection(18081, 'localhost');
			client.on('data', function(data) {
				var res = data.toString().split('\n');
				test.equal('GET / HTTP/1.1\r', res.shift());
				test.equal('Host: app1.aaa.com:18081', res.shift().trim());
				test.equal('X-Forwarded-For: 127.0.0.1', res.shift().trim());
				test.equal('X-Forwarded-Port: 18081', res.shift().trim());
				client.end();
				server.close();
				proxy.shutdown();
				test.done();
			});
			client.write('GET / HTTP/1.1\r\nHost:app1.aaa.com:18081\r\n');
		}, 100);
	},
	/* }}} */

// 	test_should_chunked_post_works_fine : function(t) {
// 	  var proxy = Proxy.create(__dirname + '/config.json');
// 		proxy.dispatch(18081);
// 		proxy.register('app1', __dirname + '/proxy_test.sock');
// 		var server  = Net.createServer(function(socket) {
// 			socket.on('error', function(e) {
// 			});
// 			socket.on('data', function(data) {
// 				socket.write(data);
// 			});
// 		});
// 		server.listen(__dirname + '/proxy_test.sock');
// 		setTimeout(function() {
// 			var client  = Net.createConnection(18081, 'localhost');
// 			var d = '';
// 			client.on('data', function(data) {
// 				d+= data;
// 			});
// 			client.on('end', function(){
// 				var res = d.toString().split('\n');
// 				console.log(res);
// 				server.close();
// 				proxy.shutdown();
// 				test.done();
// 			})
// 			client.write('POST / HTTP/1.1\r\n\
// Host:app1.aaa.com:18081\r\n\
// Content-Length:2048\r\n\
// Content-Type:application/x-www-form-urlencoded\r\n\r\n');
// 			var bf = new Buffer(512);
// 			bf.fill('a');
// 			process.nextTick(function(){
// 				client.write(bf);
// 				process.nextTick(function(){
// 					client.write(bf);
// 					process.nextTick(function(){
// 						client.write(bf);
// 						process.nextTick(function(){
// 							client.end(bf);
// 						});
// 					});
// 				});
// 			});
// 		}, 100);

// 	}

});
