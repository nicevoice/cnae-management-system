# OSS

## 限制
1. key长度 1 <= key_lenght <= 255
1. 没有文件夹概念，所以要实现文件夹修改名字会很复杂
1. putObject 文件校验需要计算md5，这个如果上传大文件，将会严重影响CPU

## Demo

import httplib
import time
from datetime import datetime

bucket = "node_chat_aliapp_com"
accessid = "6tqt8j0boslosflurd2hmu7y"
accesskey = "qhF/W4iubqok+dxz+LvFytGsZwo="
kv_host = "http://storage.aliyun.com:8080"

def build_auth(method, date, uri):
    tmp = method + "\n\n\n" + date + "\n" + uri
    h = hmac.new(accesskey, tmp, sha)
    return base64.encodestring(h.digest()).strip()
    
# 以下是python例子:

oss_url = '"/" + bucket + "/hello.txt"'
date = time.strftime("%a, %d %b %Y %H:%M:%S GMT", time.gmtime())

headers = {}

headers['Date'] = date
headers['Host'] = kv_host
headers['Authorization'] = "OSS " + accessid + ":" + build_auth("GET", date, oss_url)

conn = httplib.HTTPConnection(kv_host)
conn.request("GET", oss_url, "", headers)
response = conn.getresponse()
    
    