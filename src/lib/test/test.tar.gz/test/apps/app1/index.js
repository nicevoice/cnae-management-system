var http = require('http');
console.log(123);
console.warn(456);
var a = http.createServer(function(req, resp) {
	resp.end(req.url);
}).listen(8123)
var a = http.createServer(function(req, resp) {
	resp.end('another port: ' + req.url);
}).listen(8122);
/*setInterval(function(){
	return ;
}, 1000);*/
