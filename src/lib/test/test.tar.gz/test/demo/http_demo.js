/* vim: set expandtab tabstop=4 shiftwidth=4 foldmethod=marker: */

var Net         = require('net');
var File        = require('fs');
var Master		= require('../lib/proxy_console');

var message     = 'HTTP/1.1 200 OK\r\n';
message += 'Server: CNode App Engine/0.1.0\r\n';
message += 'Date: {__TIME__}\r\n';
message += 'Content-Type: text/html;charset=utf-8\r\n';
message += 'Content-Length: {__SIZE__}\r\n';
message += 'Connection: keep-alive\r\n';

message += '\r\n';

/* {{{ 基于UNIX SOCKET的HTTP服务 */

var skfile  = '/tmp/demo_18081.sock';
var server  = Net.createServer(function(socket) {
    socket.on('data', function(data) {
        var header  = null;
        if (data.length > 1024) {
            header  = data.slice(0, 1024).toString().trim();
        } else {
            header  = data.toString().trim();
        }

        var ipaddr  = '127.0.0.1';
        header  = header.split('\r\n\r\n').shift().split('\n');
        for (var i in header) {
            var itm = header[i].split(':');
            var key = itm.shift().trim().toLowerCase();
            if ('X-Forwarded-For' == key) {
                ipaddr  = itm.join(':').trim();
                break;
            }
        }

        var time    = new Date();
        var resp    = new Buffer('时间:' + time + '<hr/>IP地址:' + ipaddr);
        socket.write(
            message.replace(/\{__TIME__\}/g, time).replace('{__SIZE__}', resp.length) + resp
        );
    });
});
server.listen(skfile);

/* }}} */

var master	    = Master.create(__dirname + '/../config.json');
master.register('pengchun', 18081, skfile);

process.on('exit', function() {
    server.close();
    master.unregister('pengchun', 18081);
    master.shutdown(function() {
        File.unlink(skfile, function() {
            console.log('complete!');
        });
        console.log('About to quit...');
    });
});
