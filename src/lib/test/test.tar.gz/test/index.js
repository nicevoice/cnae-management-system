#!/usr/bin/env node
var argv = require('optimist').argv,
	config = require('./lib/config'),
	fs = require('fs');

var configFile = argv.f && argv.f !== true ? argv.f : __dirname + '/config.json';
config.loadFromFile(configFile);

// make all dir
try {
	fs.mkdirSync(config.getDir('log'), 0775);
} catch(e){}
try {
	fs.mkdirSync(config.getDir('run'), 0775);
} catch(e){}
try {
	fs.mkdirSync(config.getDir('route'), 0775);
} catch(e){}
try {
	fs.mkdirSync(config.getDir('fork'), 0775);
} catch(e){}

var rundir = config.getDir('run');

var run = function(modpath, name){
	var srv = require(modpath);
	var pid = rundir + '/' + name + '.pid';
	srv.run(configFile);
	fs.writeFile(pid, process.pid + '');
	process.on('exit', function(){
		try {
			fs.unlink(pid);
		} catch (e){

		}
	});
};


if (argv.s === 'master') {
	run('./lib/master', 'master');
} else if (argv.s === 'proxy') {
	run('./lib/proxy_console', 'proxy');
} else if (argv.s === 'std') {
	run('./lib/std_server', 'std');
} else {
	var dir = process.argv[1].replace(process.cwd(), '');
	if (dir === '') {
		dir = '.';
	}
	console.log('Usage:\n %s %s -s [master|proxy] -f (config_file)', process.argv[0], dir, '');
}


process.on('uncaughtException', function(e){
	console.log(e.stack.toString());
});


