var fs = require('fs'),
cp = require('child_process');
desc('Cnode app engine builder');

task('default', function(params) {
  jake.Task['unittest'].invoke();
});



task('makeconf', function(){
	var cont = fs.readFileSync('config.tpl.json');
	fs.writeFileSync(
		'config.json',
		cont.toString()
			.replace(/\s*\/\/.+$/igm, '')
			.replace(/\$\$debug\$\$/ig, 'false')
			.replace(/\$\$port_deny\$\$/ig, '"1-79","81-1024",1127,3306,20351')
			.replace(/\$\$kill_timeout\$\$/ig, '5000')
			.replace(/\$\$default_port\$\$/ig, '80')
			.replace(/\$\$uid\$\$/ig, process.getuid())
			.replace(/\$\$gid\$\$/ig, process.getgid())
			.replace(/\$\$home\$\$/ig, process.cwd())
			.replace(/\$\$allow\$\$/ig, '"socket.io-client"')
			.replace(/\$\$deny\$\$/ig, '"child_process"')
			.replace(/\$\$map\$\$/ig, '"net","fs"')
			.replace(/\$\$domain\$\$/ig, '"cnodejs.net"')
			.replace(/\$\$dev_domain\$\$/ig, '"dev.cnodejs.net"')
	);
});
task('cleanup', function(){
	try {
		fs.unlinkSync('config.json');
	} catch(e) {

	}
	jake.Task['unittest-cleanup'].invoke();
});
task('unittest-cleanup', function(){
	try {
		fs.unlinkSync('test/config.json');
	} catch(e) {

	}
});

task('unittest-makeconf', function(){
	jake.Task['unittest-cleanup'].invoke();
	var cont = fs.readFileSync('config.tpl.json');
	fs.writeFileSync(
		'test/config.json',
		cont.toString()
			.replace(/\s*\/\/.+$/igm, '')
			.replace(/\$\$debug\$\$/ig, 'true')
			.replace(/\$\$port_deny\$\$/ig, '"1-79","81-1024",1127,1128,3306,20351')
			.replace(/\$\$kill_timeout\$\$/ig, '200')
			.replace(/\$\$default_port\$\$/ig, '8080')
			.replace(/\$\$uid\$\$/ig, process.getuid())
			.replace(/\$\$gid\$\$/ig, process.getgid())
			.replace(/\$\$home\$\$/ig, process.cwd() + '/test')
			.replace(/\$\$allow\$\$/ig, '')
			.replace(/\$\$deny\$\$/ig, '')
			.replace(/\$\$map\$\$/ig, '')
            .replace(/\$\$domain\$\$/ig, '"cnodejs.local"')
            .replace(/\$\$dev_domain\$\$/ig, '"dev.cnodejs.local"')
	);
});

task('unittest', function(){
	jake.Task['unittest-makeconf'].invoke();
	require('nodeunit').reporters.default.run(['test', 'test/modules']);
	jake.Task['unittest-filesystem'].invoke();
});

task('unittest-filesystem', function(){
    require('nodeunit').reporters.default.run(['test/filesystem/oss', 'test/filesystem']);
});
