# Node APP Engine

# Must 设置sudo 免密码

# Deps

    $ npm install sax socket.io-client
    
    # install node-curl from source code
    # require libcurl-dev
    $ git clone git://github.com/zcbenz/node-curl.git
    $ cd node-curl
    $ node-waf configure && node-waf build
    $ cp build/default/node_curl.node $CNAE/node_modules

# Install & Run

	#install "Jake" & "optimist" first
	#npm install -g Jake
	#npm install optimist
	jake makeconf
	bin/start.sh

# Stop All Service

	bin/stop.sh

